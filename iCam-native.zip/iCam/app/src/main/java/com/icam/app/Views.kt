package com.icam.app

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import android.widget.LinearLayout
import kotlin.math.*

/** أيقونات مرسومة يدوياً (بدون ملفات صور) */
class IconView(c: Context, private val kind: String) : View(c) {
    private val d = c.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    var tint: Int = Color.WHITE
        set(v) { field = v; invalidate() }
    var slashed: Boolean = false
        set(v) { field = v; invalidate() }

    private fun head(c: Canvas, x: Float, y: Float, ang: Double, sz: Float) {
        val path = Path()
        path.moveTo(x, y)
        path.lineTo(x + (sz * cos(ang + PI - 0.55)).toFloat(), y + (sz * sin(ang + PI - 0.55)).toFloat())
        path.lineTo(x + (sz * cos(ang + PI + 0.55)).toFloat(), y + (sz * sin(ang + PI + 0.55)).toFloat())
        path.close()
        p.style = Paint.Style.FILL; c.drawPath(path, p); p.style = Paint.Style.STROKE
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val s = min(w, h) * 0.42f; val cx = w / 2; val cy = h / 2
        p.color = tint; p.style = Paint.Style.STROKE; p.strokeWidth = 1.9f * d
        p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND
        when (kind) {
            "bolt" -> {
                val path = Path()
                path.moveTo(cx + .15f * s, cy - s); path.lineTo(cx - .55f * s, cy + .1f * s)
                path.lineTo(cx - .02f * s, cy + .1f * s); path.lineTo(cx - .15f * s, cy + s)
                path.lineTo(cx + .55f * s, cy - .1f * s); path.lineTo(cx + .02f * s, cy - .1f * s)
                path.close(); c.drawPath(path, p)
                if (slashed) c.drawLine(cx - s, cy - s, cx + s, cy + s, p)
            }
            "look" -> { c.drawCircle(cx - s * .32f, cy, s * .66f, p); c.drawCircle(cx + s * .32f, cy, s * .66f, p) }
            "flip" -> {
                val r = RectF(cx - s, cy - s, cx + s, cy + s)
                c.drawArc(r, 200f, 130f, false, p); c.drawArc(r, 20f, 130f, false, p)
                for (a in doubleArrayOf(330.0, 150.0)) {
                    val rad = Math.toRadians(a)
                    head(c, cx + s * cos(rad).toFloat(), cy + s * sin(rad).toFloat(), rad + PI / 2, s * .55f)
                }
            }
            "dots" -> {
                p.style = Paint.Style.FILL
                for (i in -1..1) for (j in -1..1) c.drawCircle(cx + i * s * .6f, cy + j * s * .6f, s * .13f, p)
            }
            "grid" -> {
                c.drawRoundRect(cx - s, cy - s, cx + s, cy + s, 4 * d, 4 * d, p)
                c.drawLine(cx - s / 3, cy - s, cx - s / 3, cy + s, p); c.drawLine(cx + s / 3, cy - s, cx + s / 3, cy + s, p)
                c.drawLine(cx - s, cy - s / 3, cx + s, cy - s / 3, p); c.drawLine(cx - s, cy + s / 3, cx + s, cy + s / 3, p)
            }
            "chev" -> {
                p.strokeWidth = 3.4f * d
                val path = Path()
                path.moveTo(cx - s * 1.15f, cy + s * .3f); path.lineTo(cx, cy - s * .3f); path.lineTo(cx + s * 1.15f, cy + s * .3f)
                c.drawPath(path, p)
            }
            "rings" -> {
                p.pathEffect = DashPathEffect(floatArrayOf(2f * d, 3f * d), 0f)
                c.drawCircle(cx, cy, s * 1.0f, p)
                p.pathEffect = null
                c.drawCircle(cx, cy, s * .66f, p)
                p.style = Paint.Style.FILL; c.drawCircle(cx, cy, s * .3f, p)
            }
            "timer" -> {
                c.drawCircle(cx, cy + s * .1f, s * .85f, p)
                c.drawLine(cx, cy + s * .1f, cx, cy - s * .4f, p); c.drawLine(cx, cy + s * .1f, cx + s * .3f, cy + s * .35f, p)
                c.drawLine(cx - s * .3f, cy - s * .95f, cx + s * .3f, cy - s * .95f, p)
            }
        }
    }
}

/** شريط الزوم: السحب الأفقي عليه يحرّك الزوم بسلاسة (مثل عجلة الأيفون) */
class ScrubLinear(c: Context) : LinearLayout(c) {
    var onStart: (() -> Unit)? = null
    var onMove: ((Float) -> Unit)? = null
    var onEnd: (() -> Unit)? = null
    private var x0 = 0f
    private var scrub = false
    private val slop = 12 * c.resources.displayMetrics.density

    override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { x0 = e.rawX; scrub = false }
            MotionEvent.ACTION_MOVE -> if (!scrub && abs(e.rawX - x0) > slop) {
                scrub = true; x0 = e.rawX; onStart?.invoke()
            }
        }
        return scrub
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!scrub) return super.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_MOVE -> onMove?.invoke(e.rawX - x0)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { scrub = false; onEnd?.invoke() }
        }
        return true
    }
}

/** تظليل الحواف (Vignette) للمعاينة الحيّة — نفس معادلة الصورة المحفوظة */
class VignetteView(c: Context) : View(c) {
    private val vp = Paint()
    var strength: Float = 0f
        set(v) { field = v; invalidate() }

    override fun onDraw(c: Canvas) {
        if (strength <= 0f) return
        val r = hypot(width.toFloat(), height.toFloat()) / 2f
        vp.shader = RadialGradient(width / 2f, height / 2f, r, intArrayOf(0, 0, ((strength * 255).toInt() shl 24)),
            floatArrayOf(0f, .55f, 1f), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), vp)
    }
}
