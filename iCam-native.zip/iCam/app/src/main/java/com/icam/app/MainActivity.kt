package com.icam.app

import android.Manifest
import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.ContentUris
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCharacteristics
import android.media.MediaActionSound
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Size
import android.view.*
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.core.CameraFilter
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.math.*

data class Lens(val id: String, val f: Float)
class Flt(val name: String, val m: ColorMatrix?, val vig: Float)

class MainActivity : ComponentActivity() {
    private val Y = 0xFFFFD60A.toInt()
    private val RED = 0xFFFF3B30.toInt()
    private val GLASS = 0x8838383A.toInt()
    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private val MAXZ = 100f
    private val sound by lazy { MediaActionSound() }

    // views
    private lateinit var root: FrameLayout
    private lateinit var box: FrameLayout
    private lateinit var previewView: PreviewView
    private lateinit var touch: View
    private lateinit var gridV: View
    private lateinit var vigV: VignetteView
    private lateinit var focusV: View
    private lateinit var flashV: View
    private lateinit var countT: TextView
    private lateinit var readout: TextView
    private lateinit var zoomPill: ScrubLinear
    private lateinit var filterPanel: HorizontalScrollView
    private lateinit var toolsPanel: LinearLayout
    private lateinit var topBar: FrameLayout
    private lateinit var bottomCol: LinearLayout
    private lateinit var thumb: ImageView
    private lateinit var flipBtn: View
    private lateinit var flashBtn: FrameLayout
    private lateinit var flashIcon: IconView
    private lateinit var chevBtn: FrameLayout
    private lateinit var chevIcon: IconView
    private lateinit var hdrBtn: TextView
    private lateinit var settingsBtn: FrameLayout
    private lateinit var recPill: TextView
    private lateinit var lookSeek: SeekBar
    private lateinit var lookVal: TextView
    private lateinit var modeRow: LinearLayout
    private lateinit var modeStrip: FrameLayout
    private lateinit var shutterDisc: View
    private lateinit var viewer: FrameLayout
    private lateinit var viewerImg: ImageView
    private lateinit var gridBtn: LinearLayout
    private lateinit var timerBtn: LinearLayout
    private lateinit var hrBtn: LinearLayout
    private lateinit var qualBtn: LinearLayout
    private val modeTv = ArrayList<TextView>()
    private val chipLabels = ArrayList<TextView>()
    private val chipSwatches = ArrayList<View>()
    private val shutterBg = GradientDrawable()
    private var shutterColor = Color.WHITE
    private var insetTop = 0
    private var insetBottom = 0

    // camera state
    private var provider: ProcessCameraProvider? = null
    private var cam: androidx.camera.core.Camera? = null
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var rec: Recording? = null
    private var recording = false
    private var front = false
    private var lenses = listOf<Lens>()
    private var curLens: Lens? = null
    private var hwMin = 1f
    private var hwMax = 1f
    private var zoom = 1f
    private var extra = 1f
    private var switching = false
    @Volatile private var busy = false
    private var levels = listOf(1f)
    private var levelViews = listOf<TextView>()
    private var zoomAnim: ValueAnimator? = null
    private var scrubZ0 = 1f

    // exposure
    private var evIdx = 0
    private var evMin = 0
    private var evMax = 0
    private var evStep = 0f
    private var focusActive = false
    private var evY0 = 0f
    private var evBase = 0
    private var evDragging = false

    // options
    private val modeNames = listOf("VIDEO", "PHOTO", "SQUARE")
    private var modeIdx = 1
    private val isVideo get() = modeIdx == 0
    private val square get() = modeIdx == 2
    private var lookOn = true
    private var flashOn = false
    private var gridOn = false
    private var timerSec = 0
    private var hiRes = true
    private var fIdx = 0
    private val qualities = listOf(Quality.HD, Quality.FHD, Quality.UHD)
    private val qualityNames = listOf("720p", "1080p", "4K")
    private var vq = 1
    private var lastUri: Uri? = null
    private var lastIsVideo = false
    private var lastView: Bitmap? = null
    private var boxAnim: ValueAnimator? = null

    // ───────── filters (تُطبَّق على المعاينة وعلى الصورة المحفوظة بنفس المعادلة)
    private fun cm(sat: Float = 1f, con: Float = 1f, bri: Float = 0f, r: Float = 1f, g: Float = 1f, b: Float = 1f, lift: Float = 0f): ColorMatrix {
        val m = ColorMatrix().apply { setSaturation(sat) }
        val t = 128f * (1f - con) + bri + lift
        m.postConcat(ColorMatrix(floatArrayOf(
            con * r, 0f, 0f, 0f, t,
            0f, con * g, 0f, 0f, t,
            0f, 0f, con * b, 0f, t,
            0f, 0f, 0f, 1f, 0f)))
        return m
    }
    private val filters = listOf(
        Flt("Original", null, 0f),
        Flt("Vivid", cm(sat = 1.32f, con = 1.08f), 0f),
        Flt("Warm", cm(sat = 1.15f, con = 1.04f, r = 1.08f, b = .92f), 0f),
        Flt("Cool", cm(sat = 1.1f, r = .94f, b = 1.08f), 0f),
        Flt("Dramatic", cm(sat = .8f, con = 1.3f), .5f),
        Flt("Cinema", cm(sat = 1.12f, con = 1.15f, r = 1.05f, g = .99f, b = .95f), .25f),
        Flt("Golden", cm(sat = 1.15f, bri = 6f, r = 1.14f, g = 1.05f, b = .84f), .1f),
        Flt("Chrome", cm(sat = 1.2f, con = 1.18f, r = .98f, b = 1.04f), .15f),
        Flt("Fade", cm(sat = .8f, con = .88f, r = 1.03f, lift = 20f), 0f),
        Flt("Pastel", cm(sat = .75f, con = .9f, bri = 14f, lift = 10f), 0f),
        Flt("Mono", cm(sat = 0f, con = 1.08f), 0f),
        Flt("Silver", cm(sat = 0f, con = .95f, b = 1.03f, lift = 14f), 0f),
        Flt("Noir", cm(sat = 0f, con = 1.35f, bri = -8f), .55f)
    )

    private val permReq = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startCamera() else toast("Camera permission is required")
    }
    private val audioReq = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun dpf(v: Float) = v * resources.displayMetrics.density
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun haptic() { root.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK) }
    private fun oval(c: Int) = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(c) }
    private fun rr(c: Int, r: Float) = GradientDrawable().apply { shape = GradientDrawable.RECTANGLE; cornerRadius = r; setColor(c) }
    private fun ring(c: Int) = GradientDrawable().apply { shape = GradientDrawable.OVAL; setStroke(max(2, dpf(1.6f).toInt()), c); setColor(0) }
    private fun pillStroke(c: Int) = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE; cornerRadius = dpf(16f); setStroke(max(2, dpf(1.6f).toInt()), c); setColor(0)
    }
    private fun fl(w: Int, h: Int, g: Int = Gravity.NO_GRAVITY) = FrameLayout.LayoutParams(w, h, g)
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private fun label(t: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color); gravity = Gravity.CENTER
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun bounce(v: View, onClick: () -> Unit) {
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN ->
                    view.animate().scaleX(.88f).scaleY(.88f).setDuration(90).setInterpolator(DecelerateInterpolator()).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    view.animate().scaleX(1f).scaleY(1f).setDuration(280).setInterpolator(OvershootInterpolator(3.2f)).start()
                    if (e.actionMasked == MotionEvent.ACTION_UP && e.x in 0f..view.width.toFloat() && e.y in 0f..view.height.toFloat()) {
                        haptic(); onClick()
                    }
                }
            }
            true
        }
    }

    // ───────────────────────── lifecycle
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        buildUi()
        setContentView(root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { _, ins ->
            val s = ins.getInsets(WindowInsetsCompat.Type.systemBars())
            insetTop = s.top; insetBottom = s.bottom; layoutAll(); ins
        }
        loadLatest()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
            startCamera() else permReq.launch(Manifest.permission.CAMERA)
    }

    override fun onPause() { if (recording) stopRecording(); super.onPause() }
    override fun onDestroy() { super.onDestroy(); io.shutdown() }

    override fun onKeyDown(code: Int, e: KeyEvent): Boolean {
        if (code == KeyEvent.KEYCODE_VOLUME_DOWN || code == KeyEvent.KEYCODE_VOLUME_UP) { shoot(); return true }
        return super.onKeyDown(code, e)
    }

    private fun availH(): Int {
        val h = if (root.height > 0) root.height else resources.displayMetrics.heightPixels
        return h - (insetTop + dp(52)) - (dp(144) + insetBottom + dp(8))
    }
    private fun boxHeightFor(i: Int): Int {
        val w = resources.displayMetrics.widthPixels
        return when (i) { 0 -> min(w * 16 / 9, availH()); 2 -> w; else -> w * 4 / 3 }
    }
    private fun layoutAll() {
        val lp = box.layoutParams as FrameLayout.LayoutParams
        lp.topMargin = insetTop + dp(52)
        if (modeIdx == 0 && boxAnim?.isRunning != true) lp.height = boxHeightFor(0)
        box.layoutParams = lp
        (topBar.layoutParams as FrameLayout.LayoutParams).topMargin = insetTop
        topBar.requestLayout()
        bottomCol.setPadding(0, 0, 0, insetBottom + dp(8))
    }

    // ───────────────────────── UI
    @SuppressLint("ClickableViewAccessibility")
    private fun buildUi() {
        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }

        // ── top bar (مثل لقطة الشاشة): فلاش • سهم • HDR • الإعدادات
        flashIcon = IconView(this, "bolt").apply { slashed = false }
        flashBtn = FrameLayout(this).apply { background = ring(Color.WHITE); addView(flashIcon, fl(dp(20), dp(20), Gravity.CENTER)) }
        chevIcon = IconView(this, "chev").apply { tint = 0xCCFFFFFF.toInt() }
        chevBtn = FrameLayout(this).apply { addView(chevIcon, fl(dp(44), dp(28), Gravity.CENTER)) }
        hdrBtn = label("HDR", 13f, Color.WHITE, true).apply {
            background = pillStroke(Color.WHITE); setPadding(dp(13), dp(5), dp(13), dp(5)); letterSpacing = .06f
        }
        settingsBtn = FrameLayout(this).apply { addView(IconView(context, "rings"), fl(dp(30), dp(30), Gravity.CENTER)) }
        recPill = label("00:00", 14f, Color.WHITE, true).apply {
            background = rr(RED, dpf(8f)); setPadding(dp(12), dp(3), dp(12), dp(3)); visibility = View.GONE
        }
        topBar = FrameLayout(this).apply {
            addView(flashBtn, fl(dp(38), dp(38), Gravity.START or Gravity.CENTER_VERTICAL).apply { marginStart = dp(16) })
            addView(chevBtn, fl(dp(64), dp(44), Gravity.CENTER))
            addView(recPill, fl(WRAP, WRAP, Gravity.CENTER))
            addView(hdrBtn, fl(WRAP, WRAP, Gravity.END or Gravity.CENTER_VERTICAL).apply { marginEnd = dp(62) })
            addView(settingsBtn, fl(dp(40), dp(40), Gravity.END or Gravity.CENTER_VERTICAL).apply { marginEnd = dp(14) })
        }
        bounce(flashBtn) { toggleFlash() }
        bounce(chevBtn) { showPanel(filterPanel) }
        bounce(settingsBtn) { showPanel(toolsPanel) }
        bounce(hdrBtn) {
            lookOn = !lookOn; hdrBtn.alpha = if (lookOn) 1f else .45f; applyLookPreview()
            toast(if (lookOn) "HDR look on" else "HDR look off")
        }

        // ── viewfinder
        box = FrameLayout(this).apply { clipChildren = true; setBackgroundColor(0xFF111111.toInt()) }
        previewView = PreviewView(this).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
        box.addView(previewView, fl(MATCH, MATCH))
        vigV = VignetteView(this)
        box.addView(vigV, fl(MATCH, MATCH))
        gridV = object : View(this) {
            val gp = Paint().apply { color = 0x66FFFFFF; strokeWidth = dpf(1f) }
            override fun onDraw(c: Canvas) {
                for (i in 1..2) {
                    c.drawLine(width * i / 3f, 0f, width * i / 3f, height.toFloat(), gp)
                    c.drawLine(0f, height * i / 3f, width.toFloat(), height * i / 3f, gp)
                }
            }
        }.apply { alpha = 0f }
        box.addView(gridV, fl(MATCH, MATCH))
        touch = View(this)
        box.addView(touch, fl(MATCH, MATCH))
        focusV = View(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.RECTANGLE; setStroke(dp(2), Y); setColor(0) }
            alpha = 0f
        }
        box.addView(focusV, fl(dp(76), dp(76)))
        flashV = View(this).apply { setBackgroundColor(Color.BLACK); alpha = 0f }
        box.addView(flashV, fl(MATCH, MATCH))
        countT = label("", 96f).apply { typeface = Typeface.create("sans-serif-thin", Typeface.NORMAL); visibility = View.GONE }
        box.addView(countT, fl(MATCH, MATCH))

        // ── zoom circles (دوائر منفصلة كما في الصورة)
        readout = label("1×", 14f, Y, true).apply {
            background = rr(0x99000000.toInt(), dpf(20f)); setPadding(dp(12), dp(5), dp(12), dp(5)); alpha = 0f
        }
        box.addView(readout, fl(WRAP, WRAP, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(66) })
        zoomPill = ScrubLinear(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        box.addView(zoomPill, fl(WRAP, WRAP, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(14) })
        zoomPill.onStart = { zoomAnim?.cancel(); scrubZ0 = zoom }
        zoomPill.onMove = { dx ->
            applyZoom(scrubZ0 * exp(dx / (resources.displayMetrics.widthPixels * .45f) * ln(10f))); showReadout()
        }

        // ── filters strip
        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(10), dp(8), dp(10), dp(6)) }
        for ((i, f) in filters.withIndex()) {
            val sw = ImageView(this).apply {
                setImageBitmap(swatch(f)); scaleType = ImageView.ScaleType.CENTER_CROP
                background = rr(0xFF222222.toInt(), dpf(10f)); outlineProvider = ViewOutlineProvider.BACKGROUND; clipToOutline = true
            }
            val lb = label(f.name, 11f, Color.WHITE, false)
            chipSwatches.add(sw); chipLabels.add(lb)
            val chip = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
                addView(sw, LinearLayout.LayoutParams(dp(58), dp(58)))
                addView(lb, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(4) })
            }
            chips.addView(chip, LinearLayout.LayoutParams(dp(66), WRAP))
            chip.setOnClickListener { selectFilter(i) }
        }
        filterPanel = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false; background = rr(0xBB000000.toInt(), dpf(0f)); visibility = View.GONE
            addView(chips)
        }
        box.addView(filterPanel, fl(MATCH, WRAP, Gravity.BOTTOM).apply { bottomMargin = dp(60) })
        selectFilter(0, false)

        // ── settings sheet
        lookSeek = SeekBar(this).apply {
            max = 100; progress = 80
            progressTintList = ColorStateList.valueOf(Y); thumbTintList = ColorStateList.valueOf(Y)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) { lookVal.text = "$p"; applyLookPreview() }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        lookVal = label("80", 14f)
        fun toolBtn(icon: View, text: String): LinearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            background = rr(0x22FFFFFF, dpf(12f)); setPadding(0, dp(10), 0, dp(8))
            addView(icon, LinearLayout.LayoutParams(WRAP, dp(26)))
            addView(label(text, 11f))
        }
        gridBtn = toolBtn(IconView(this, "grid").apply { minimumWidth = dp(26) }, "Grid")
        timerBtn = toolBtn(IconView(this, "timer").apply { minimumWidth = dp(26) }, "Timer off")
        hrBtn = toolBtn(label("HR", 17f, Y, true), "Hi-Res")
        qualBtn = toolBtn(label(qualityNames[vq], 15f, Y, true), "Video")
        hrBtn.background = rr(0x44FFD60A, dpf(12f))
        val btnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            for (bt in listOf(gridBtn, timerBtn, hrBtn, qualBtn))
                addView(bt, LinearLayout.LayoutParams(0, WRAP, 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        }
        toolsPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = rr(0xDD28282A.toInt(), dpf(18f))
            setPadding(dp(14), dp(12), dp(14), dp(12)); visibility = View.GONE
            val head = LinearLayout(context).apply {
                addView(label("Look intensity", 13f, Color.WHITE, true), LinearLayout.LayoutParams(0, WRAP, 1f))
                addView(lookVal)
            }
            addView(head, LinearLayout.LayoutParams(MATCH, WRAP))
            addView(lookSeek, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(8) })
            addView(btnRow, LinearLayout.LayoutParams(MATCH, WRAP))
        }
        box.addView(toolsPanel, fl(MATCH, WRAP, Gravity.BOTTOM).apply { setMargins(dp(12), 0, dp(12), dp(66)) })
        bounce(gridBtn) {
            gridOn = !gridOn; gridV.animate().alpha(if (gridOn) 1f else 0f).setDuration(220).start()
            gridBtn.background = rr(if (gridOn) 0x44FFD60A else 0x22FFFFFF, dpf(12f))
        }
        bounce(timerBtn) {
            timerSec = when (timerSec) { 0 -> 3; 3 -> 10; else -> 0 }
            (timerBtn.getChildAt(1) as TextView).text = if (timerSec == 0) "Timer off" else "Timer ${timerSec}s"
            timerBtn.background = rr(if (timerSec > 0) 0x44FFD60A else 0x22FFFFFF, dpf(12f))
        }
        bounce(hrBtn) {
            hiRes = !hiRes
            hrBtn.background = rr(if (hiRes) 0x44FFD60A else 0x22FFFFFF, dpf(12f))
            toast(if (hiRes) "Hi-Res on (max sensor detail)" else "Hi-Res off (faster)")
            if (!isVideo) bind(curLens)
        }
        bounce(qualBtn) {
            if (recording) return@bounce
            vq = (vq + 1) % qualities.size
            (qualBtn.getChildAt(0) as TextView).text = qualityNames[vq]
            toast("Video ${qualityNames[vq]}")
            if (isVideo) bind(curLens)
        }

        // ── bottom: modes + shutter row
        for ((i, n) in modeNames.withIndex()) {
            val t = label(n, 14f, if (i == modeIdx) Y else Color.WHITE, true).apply {
                letterSpacing = .06f; setPadding(dp(20), dp(10), dp(20), dp(10))
                setOnClickListener { setModeIdx(i) }
            }
            modeTv.add(t)
        }
        modeRow = LinearLayout(this).apply { for (t in modeTv) addView(t) }
        modeStrip = FrameLayout(this).apply { clipChildren = true; addView(modeRow, fl(WRAP, MATCH)) }
        modeStrip.post { centerMode(modeIdx, false) }

        thumb = ImageView(this).apply {
            background = rr(0xFF2A2A2C.toInt(), dpf(9f)); scaleType = ImageView.ScaleType.CENTER_CROP
            outlineProvider = ViewOutlineProvider.BACKGROUND; clipToOutline = true
        }
        bounce(thumb) { openViewer() }
        shutterBg.shape = GradientDrawable.RECTANGLE; shutterBg.setColor(Color.WHITE); shutterBg.cornerRadius = dpf(34f)
        shutterDisc = View(this).apply { background = shutterBg }
        val shutter = FrameLayout(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setStroke(dp(4), Color.WHITE); setColor(0) }
            addView(shutterDisc, fl(dp(68), dp(68), Gravity.CENTER))
        }
        bounce(shutter) { shoot() }
        flipBtn = FrameLayout(this).apply { background = oval(GLASS); addView(IconView(context, "flip"), fl(dp(30), dp(30), Gravity.CENTER)) }
        bounce(flipBtn) { flipCamera() }
        val controls = FrameLayout(this).apply {
            addView(thumb, fl(dp(56), dp(56), Gravity.START or Gravity.CENTER_VERTICAL).apply { marginStart = dp(24) })
            addView(shutter, fl(dp(84), dp(84), Gravity.CENTER))
            addView(flipBtn, fl(dp(56), dp(56), Gravity.END or Gravity.CENTER_VERTICAL).apply { marginEnd = dp(24) })
        }
        bottomCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(modeStrip, LinearLayout.LayoutParams(MATCH, dp(44)))
            addView(controls, LinearLayout.LayoutParams(MATCH, dp(100)))
        }

        // ── viewer
        viewerImg = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
        val done = label("Done", 17f, 0xFF0A84FF.toInt()).apply { setPadding(dp(24), dp(14), dp(24), dp(14)) }
        val share = label("Share", 17f, 0xFF0A84FF.toInt()).apply { setPadding(dp(24), dp(14), dp(24), dp(14)) }
        done.setOnClickListener { closeViewer() }
        share.setOnClickListener { shareLast() }
        viewer = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK); visibility = View.GONE; isClickable = true
            addView(viewerImg, fl(MATCH, MATCH).apply { topMargin = dp(40); bottomMargin = dp(70) })
            addView(done, fl(WRAP, WRAP, Gravity.BOTTOM or Gravity.START).apply { bottomMargin = dp(16) })
            addView(share, fl(WRAP, WRAP, Gravity.BOTTOM or Gravity.END).apply { bottomMargin = dp(16) })
        }

        root.addView(box, fl(MATCH, resources.displayMetrics.widthPixels * 4 / 3, Gravity.TOP).apply { topMargin = dp(80) })
        root.addView(topBar, fl(MATCH, dp(52), Gravity.TOP))
        root.addView(bottomCol, fl(MATCH, WRAP, Gravity.BOTTOM))
        root.addView(viewer, fl(MATCH, MATCH))

        // gestures: قرص للزوم • نقرة للتركيز • سحب رأسي للإضاءة • سحب أفقي لتبديل الوضع
        val scaleDet = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScaleBegin(d: ScaleGestureDetector): Boolean { zoomAnim?.cancel(); return true }
            override fun onScale(d: ScaleGestureDetector): Boolean { applyZoom(zoom * d.scaleFactor); showReadout(); return true }
        })
        val tapDet = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onSingleTapUp(e: MotionEvent): Boolean { focusAt(e.x, e.y); return true }
            override fun onFling(a: MotionEvent?, b: MotionEvent, vx: Float, vy: Float): Boolean {
                if (!evDragging && abs(vx) > abs(vy) * 2f && abs(vx) > 1200f) {
                    setModeIdx((modeIdx + if (vx < 0) 1 else -1).coerceIn(0, modeNames.size - 1)); return true
                }
                return false
            }
        })
        touch.setOnTouchListener { _, e ->
            scaleDet.onTouchEvent(e)
            if (!scaleDet.isInProgress && e.pointerCount == 1) { tapDet.onTouchEvent(e); if (focusActive) evDrag(e) }
            true
        }
        previewView.previewStreamState.observe(this) {
            if (it == PreviewView.StreamState.STREAMING) {
                previewView.animate().alpha(1f).setDuration(200).start(); applyLookPreview()
            }
        }
        updateShutter(false)
    }

    // ───────────────────────── panels / modes / shutter
    private fun showPanel(p: View) {
        val opening = p.visibility != View.VISIBLE
        for (v in listOf(filterPanel as View, toolsPanel as View)) {
            if (v === p && v.visibility != View.VISIBLE) {
                v.visibility = View.VISIBLE; v.alpha = 0f; v.translationY = dpf(24f)
                v.animate().alpha(1f).translationY(0f).setDuration(240).setInterpolator(DecelerateInterpolator()).start()
            } else if (v.visibility == View.VISIBLE) {
                v.animate().alpha(0f).translationY(dpf(24f)).setDuration(180).withEndAction { v.visibility = View.GONE }.start()
            }
        }
        chevIcon.animate().rotation(if (p === filterPanel && opening) 180f else 0f).setDuration(250).start()
    }
    private fun hidePanels() {
        for (v in listOf(filterPanel as View, toolsPanel as View)) if (v.visibility == View.VISIBLE)
            v.animate().alpha(0f).translationY(dpf(24f)).setDuration(180).withEndAction { v.visibility = View.GONE }.start()
        chevIcon.animate().rotation(0f).setDuration(250).start()
    }

    private fun centerMode(i: Int, animate: Boolean) {
        val t = modeTv[i]
        val target = modeStrip.width / 2f - (t.left + t.width / 2f)
        if (animate) modeRow.animate().translationX(target).setDuration(320).setInterpolator(DecelerateInterpolator(1.5f)).start()
        else modeRow.translationX = target
    }

    private fun setModeIdx(i: Int) {
        if (i == modeIdx || recording || busy) return
        val wasVideo = isVideo
        modeIdx = i
        for (j in modeTv.indices) modeTv[j].setTextColor(if (j == i) Y else Color.WHITE)
        centerMode(i, true); haptic(); hidePanels()
        val lp = box.layoutParams
        boxAnim?.cancel()
        boxAnim = ValueAnimator.ofInt(lp.height, boxHeightFor(i)).apply {
            duration = 340; interpolator = DecelerateInterpolator(1.4f)
            addUpdateListener { lp.height = it.animatedValue as Int; box.layoutParams = lp }
            start()
        }
        hdrBtn.visibility = if (isVideo) View.INVISIBLE else View.VISIBLE
        updateShutter(true); applyLookPreview()
        if (wasVideo != isVideo) {
            if (isVideo && ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
                audioReq.launch(Manifest.permission.RECORD_AUDIO)
            previewView.animate().alpha(.15f).setDuration(90).start()
            main.postDelayed({ bind(curLens) }, 100)
        }
    }

    /** الزر الأبيض في الصور • أحمر في الفيديو • مربع أحمر أثناء التسجيل */
    private fun updateShutter(animate: Boolean) {
        val size = if (isVideo && recording) dp(30) else dp(68)
        val radius = if (isVideo && recording) dpf(8f) else size / 2f
        val color = if (isVideo) RED else Color.WHITE
        val lp = shutterDisc.layoutParams
        val s0 = lp.width; val r0 = shutterBg.cornerRadius; val c0 = shutterColor
        if (!animate) {
            lp.width = size; lp.height = size; shutterDisc.layoutParams = lp
            shutterBg.cornerRadius = radius; shutterBg.setColor(color); shutterColor = color; return
        }
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 260; interpolator = DecelerateInterpolator()
            addUpdateListener {
                val t = it.animatedValue as Float
                lp.width = (s0 + (size - s0) * t).toInt(); lp.height = lp.width; shutterDisc.layoutParams = lp
                shutterBg.cornerRadius = r0 + (radius - r0) * t
                shutterColor = ArgbEvaluator().evaluate(t, c0, color) as Int
                shutterBg.setColor(shutterColor)
            }
            start()
        }
    }

    private fun showReadout() = showReadoutText(fmt(zoom) + "×")
    private fun showReadoutText(t: String) {
        readout.text = t
        readout.animate().alpha(1f).setDuration(80).start()
        main.removeCallbacks(hideReadout); main.postDelayed(hideReadout, 900)
    }
    private val hideReadout = Runnable { readout.animate().alpha(0f).setDuration(300).start() }
    private fun fmt(z: Float) = if (abs(z - z.roundToInt()) < .05f) "${z.roundToInt()}" else String.format(Locale.US, "%.1f", z)

    // ───────────────────────── filters + look (live preview)
    private fun swatch(f: Flt): Bitmap {
        val bmp = Bitmap.createBitmap(116, 116, Bitmap.Config.ARGB_8888)
        val p = Paint()
        p.shader = LinearGradient(0f, 0f, 116f, 116f,
            intArrayOf(0xFF5B9BD5.toInt(), 0xFF8FBF6A.toInt(), 0xFFE8C39E.toInt(), 0xFFC0504D.toInt()), null, Shader.TileMode.CLAMP)
        f.m?.let { p.colorFilter = ColorMatrixColorFilter(it) }
        Canvas(bmp).drawRect(0f, 0f, 116f, 116f, p)
        return bmp
    }

    private fun selectFilter(i: Int, feedback: Boolean = true) {
        fIdx = i
        for (j in chipLabels.indices) {
            val on = j == i
            chipLabels[j].setTextColor(if (on) Y else Color.WHITE)
            chipSwatches[j].animate().scaleX(if (on) 1.1f else 1f).scaleY(if (on) 1.1f else 1f).alpha(if (on) 1f else .85f).setDuration(180).start()
        }
        if (feedback) haptic()
        applyLookPreview()
    }

    private fun lookK() = if (lookOn) lookSeek.progress / 100f else 0f

    private fun lookMatrix(k: Float): ColorMatrix {
        val sat = ColorMatrix().apply { setSaturation(1f - .07f * k) }
        val c = 1f + .05f * k
        val tt = 128f * (1f - c) + 6f * k
        val cmx = ColorMatrix(floatArrayOf(
            c * (1f + .025f * k), 0f, 0f, 0f, tt,
            0f, c, 0f, 0f, tt,
            0f, 0f, c * (1f - .035f * k), 0f, tt,
            0f, 0f, 0f, 1f, 0f))
        val m = ColorMatrix(); m.postConcat(sat); m.postConcat(cmx)
        return m
    }

    private fun findTexture(v: View): TextureView? {
        if (v is TextureView) return v
        if (v is ViewGroup) for (i in 0 until v.childCount) findTexture(v.getChildAt(i))?.let { return it }
        return null
    }
    private fun applyLookPreview(retries: Int = 6) {
        val t = findTexture(previewView)
        if (t == null) { if (retries > 0) main.postDelayed({ applyLookPreview(retries - 1) }, 200); return }
        val paint = Paint()
        val f = filters[fIdx]
        if (!isVideo) {      // الفيديو يُسجَّل بدون فلاتر، فلا نخدع المعاينة
            val k = lookK()
            if (k > 0f || f.m != null) {
                val m = ColorMatrix()
                if (k > 0f) m.postConcat(lookMatrix(k))
                f.m?.let { m.postConcat(it) }
                paint.colorFilter = ColorMatrixColorFilter(m)
            }
        }
        t.setLayerPaint(paint)
        vigV.strength = if (isVideo) 0f else f.vig
    }

    // ───────────────────────── camera
    private fun startCamera() {
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            provider = f.get(); discoverLenses(); buildLevels()
            bind(lenses.firstOrNull { abs(it.f - 1f) < .12f })
        }, ContextCompat.getMainExecutor(this))
    }

    /** يكتشف عدسات الخلفية ويحسب الزوم المكافئ لكل واحدة نسبةً للعدسة الرئيسية */
    private fun discoverLenses() {
        val p = provider ?: return
        val raw = ArrayList<Pair<String, Float>>()
        for (info in p.availableCameraInfos) {
            try {
                val c2 = Camera2CameraInfo.from(info)
                if (c2.getCameraCharacteristic(CameraCharacteristics.LENS_FACING) != CameraCharacteristics.LENS_FACING_BACK) continue
                val focal = c2.getCameraCharacteristic(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.firstOrNull() ?: continue
                val sz = c2.getCameraCharacteristic(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE) ?: continue
                raw.add(Pair(c2.cameraId, focal * 43.27f / hypot(sz.width, sz.height)))
            } catch (_: Exception) {}
        }
        if (raw.isEmpty()) { lenses = emptyList(); return }
        val mainEq = raw.minByOrNull { abs(it.second - 24f) }!!
        val res = mutableListOf(Lens(mainEq.first, 1f))
        for (o in raw.sortedBy { it.second }) {
            val f = o.second / mainEq.second
            if (o.first != mainEq.first && f in .4f..12f && res.none { abs(it.f / f - 1f) < .12f }) res.add(Lens(o.first, f))
        }
        lenses = res.sortedBy { it.f }
    }

    private fun bind(lens: Lens?) {
        val p = provider ?: return
        p.unbindAll()
        curLens = lens
        val selector = when {
            front -> CameraSelector.DEFAULT_FRONT_CAMERA
            lens != null -> CameraSelector.Builder().requireLensFacing(CameraSelector.LENS_FACING_BACK)
                .addCameraFilter(CameraFilter { infos ->
                    infos.filter { try { Camera2CameraInfo.from(it).cameraId == lens.id } catch (e: Exception) { false } }
                }).build()
            else -> CameraSelector.DEFAULT_BACK_CAMERA
        }
        val ratio = if (isVideo) AspectRatioStrategy.RATIO_16_9_FALLBACK_AUTO_STRATEGY else AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY
        val rs = ResolutionSelector.Builder().setAspectRatioStrategy(ratio).build()
        val preview = Preview.Builder().setResolutionSelector(rs).build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
        try {
            if (isVideo) {
                val q = qualities[vq]
                val recorder = Recorder.Builder().setQualitySelector(QualitySelector.from(q, FallbackStrategy.lowerQualityOrHigherThan(q))).build()
                val vc = VideoCapture.Builder(recorder).setVideoStabilizationEnabled(true).build()
                cam = p.bindToLifecycle(this, selector, preview, vc)
                videoCapture = vc; imageCapture = null
            } else {
                val capRs = ResolutionSelector.Builder().setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY)
                    .setResolutionStrategy(ResolutionStrategy.HIGHEST_AVAILABLE_STRATEGY)
                    .apply { if (hiRes) setAllowedResolutionMode(ResolutionSelector.PREFER_HIGHER_RESOLUTION_OVER_CAPTURE_RATE) }.build()
                val ic = ImageCapture.Builder().setResolutionSelector(capRs)
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                    .setFlashMode(if (flashOn) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF).build()
                cam = p.bindToLifecycle(this, selector, preview, ic)
                imageCapture = ic; videoCapture = null
            }
        } catch (e: Exception) {
            if (!front && lens != null) {
                lenses = lenses.filter { it.id != lens.id }
                buildLevels()
                bind(lenses.firstOrNull { abs(it.f - 1f) < .12f }); return
            }
            previewView.animate().alpha(1f).start(); toast("Camera error: ${e.message}"); return
        }
        val c = cam!!
        evIdx = 0
        val rg = c.cameraInfo.exposureState.exposureCompensationRange
        evMin = rg.lower; evMax = rg.upper
        evStep = try { c.cameraInfo.exposureState.exposureCompensationStep.toFloat() } catch (_: Exception) { 0f }
        if (isVideo && flashOn) c.cameraControl.enableTorch(true)
        var seen = false
        c.cameraInfo.zoomState.observe(this) { zs ->
            if (!seen || abs(zs.minZoomRatio - hwMin) > .01f || abs(zs.maxZoomRatio - hwMax) > .01f) {
                seen = true; hwMin = zs.minZoomRatio; hwMax = zs.maxZoomRatio; applyZoom(zoom)
            }
        }
    }

    private fun minTotal() = if (front || lenses.isEmpty()) 1f else lenses.first().f

    private fun applyZoom(z0: Float) {
        val z = z0.coerceIn(minTotal(), MAXZ)
        if (!front && lenses.size > 1 && !switching && !recording) {
            val want = lenses.lastOrNull { it.f <= z * 1.12f } ?: lenses.first()
            if (want.id != curLens?.id) {
                zoom = z; switching = true
                previewView.animate().alpha(.15f).setDuration(90).start()
                main.postDelayed({ bind(want); switching = false }, 100)
                return
            }
        }
        val f = if (front) 1f else (curLens?.f ?: 1f)
        val req = z / f
        val hw = req.coerceIn(hwMin, hwMax)
        extra = if (req > hw && !isVideo) req / hw else 1f   // الفيديو: بصري فقط (الرقمي لا يُسجَّل)
        zoom = max(hw * f * extra, minTotal())
        cam?.cameraControl?.setZoomRatio(hw)
        previewView.scaleX = extra; previewView.scaleY = extra
        refreshZoomUi()
    }

    private fun animateZoom(target: Float) {
        zoomAnim?.cancel()
        val z0 = zoom
        val dur = 380L + (260 * abs(log10(max(target, .1f) / max(z0, .1f)))).toLong()
        zoomAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = dur; interpolator = DecelerateInterpolator(1.5f)
            addUpdateListener { applyZoom(z0 * (target / z0).pow(it.animatedValue as Float)); showReadout() }
            start()
        }
    }

    private fun buildLevels() {
        val set = sortedSetOf<Float>()
        if (front) { set.add(1f); set.add(2f); set.add(3f) } else {
            for (l in lenses) {
                val f = l.f
                set.add(if (f < 1f) (f * 10).roundToInt() / 10f else if (abs(f - f.roundToInt()) < .3f) f.roundToInt().toFloat() else (f * 10).roundToInt() / 10f)
            }
            set.add(1f); set.add(2f)
            if (lenses.none { it.f >= 4f }) { set.add(5f); set.add(10f) }
            set.add(30f); set.add(100f)
        }
        levels = set.toList()
        zoomPill.removeAllViews()
        levelViews = levels.map { lv ->
            label("", 12f, Color.WHITE, true).apply {
                minWidth = dp(34); minHeight = dp(34)
                setPadding(dp(4), 0, dp(4), 0)
                zoomPill.addView(this, LinearLayout.LayoutParams(WRAP, dp(34)).apply { setMargins(dp(3), 0, dp(3), 0) })
                bounce(this) { animateZoom(lv) }
            }
        }
        refreshZoomUi()
    }

    private fun refreshZoomUi() {
        if (levels.isEmpty() || levelViews.size != levels.size) return
        val act = levels.indexOfLast { it <= zoom + .05f }.coerceAtLeast(0)
        for (i in levels.indices) {
            val v = levelViews[i]
            if (i == act) {
                v.text = fmt(zoom) + "×"; v.setTextColor(Y); v.background = oval(0xCC1C1C1E.toInt())
                if (v.scaleX < 1.05f) v.animate().scaleX(1.1f).scaleY(1.1f).setDuration(120).start()
            } else {
                val l = levels[i]
                v.text = if (l < 1f) fmt(l).replace("0.", ".") else fmt(l)
                v.setTextColor(Color.WHITE); v.background = oval(0x80202022.toInt())
                if (v.scaleX > 1f) v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
            }
        }
    }

    private fun flipCamera() {
        if (recording) return
        front = !front; zoom = 1f; extra = 1f
        flipBtn.animate().rotationBy(180f).setDuration(380).setInterpolator(DecelerateInterpolator()).start()
        previewView.animate().alpha(.1f).scaleX(.96f).scaleY(.96f).setDuration(140).start()
        main.postDelayed({
            previewView.scaleX = 1f; previewView.scaleY = 1f
            buildLevels(); bind(if (front) null else lenses.firstOrNull { abs(it.f - 1f) < .12f })
        }, 150)
    }

    private fun toggleFlash() {
        if (cam?.cameraInfo?.hasFlashUnit() != true) { toast("Flash not available"); return }
        flashOn = !flashOn
        flashIcon.tint = if (flashOn) Y else Color.WHITE
        flashBtn.background = ring(if (flashOn) Y else Color.WHITE)
        if (isVideo) cam?.cameraControl?.enableTorch(flashOn)
        else imageCapture?.flashMode = if (flashOn) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF
    }

    private fun focusAt(x: Float, y: Float) {
        hidePanels()
        try {
            val pt = previewView.meteringPointFactory.createPoint(x, y)
            cam?.cameraControl?.startFocusAndMetering(FocusMeteringAction.Builder(pt).setAutoCancelDuration(3, TimeUnit.SECONDS).build())
        } catch (_: Exception) {}
        focusV.x = x - dp(38); focusV.y = y - dp(38)
        focusV.animate().cancel(); focusV.alpha = 1f; focusV.scaleX = 1.5f; focusV.scaleY = 1.5f
        focusV.animate().scaleX(1f).scaleY(1f).setDuration(220).withEndAction {
            focusV.animate().alpha(0f).setStartDelay(1800).setDuration(300).start()
        }.start()
        focusActive = true
        main.removeCallbacks(endFocus); main.postDelayed(endFocus, 3000)
        haptic()
    }
    private val endFocus = Runnable { focusActive = false }

    /** سحب رأسي بعد التركيز = تعويض التعريض (الشمس في الأيفون) */
    private fun evDrag(e: MotionEvent) {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { evY0 = e.y; evBase = evIdx; evDragging = false }
            MotionEvent.ACTION_MOVE -> {
                val dy = evY0 - e.y
                if (!evDragging && abs(dy) > dp(14)) evDragging = true
                if (evDragging && evMax > evMin) {
                    val idx = (evBase + dy / dp(26)).roundToInt().coerceIn(evMin, evMax)
                    if (idx != evIdx) {
                        evIdx = idx; cam?.cameraControl?.setExposureCompensationIndex(idx)
                        val ev = idx * evStep
                        showReadoutText("EV " + (if (ev > 0) "+" else "") + String.format(Locale.US, "%.1f", ev))
                        main.removeCallbacks(endFocus); main.postDelayed(endFocus, 3000)
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> main.postDelayed({ evDragging = false }, 150)
        }
    }

    // ───────────────────────── shoot (photo / video)
    private fun shoot() {
        if (isVideo) {
            if (recording) { stopRecording(); return }
            if (busy) return
            busy = true
            val go = { startRecording(); busy = false }
            if (timerSec > 0) countdown(timerSec, go) else go()
            return
        }
        if (busy || imageCapture == null) return
        busy = true
        if (timerSec > 0) countdown(timerSec) { capture() } else capture()
    }

    private fun countdown(n: Int, done: () -> Unit) {
        if (n == 0) { countT.visibility = View.GONE; done(); return }
        countT.text = "$n"; countT.visibility = View.VISIBLE; countT.alpha = 1f; countT.scaleX = 1.5f; countT.scaleY = 1.5f
        countT.animate().scaleX(1f).scaleY(1f).alpha(.35f).setDuration(900).start()
        main.postDelayed({ countdown(n - 1, done) }, 1000)
    }

    // ── video
    @SuppressLint("MissingPermission")
    private fun startRecording() {
        val vc = videoCapture ?: return
        val cv = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "VID_${System.currentTimeMillis()}")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/iCam")
        }
        val opts = MediaStoreOutputOptions.Builder(contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI).setContentValues(cv).build()
        var pr = vc.output.prepareRecording(this, opts)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) pr = pr.withAudioEnabled()
        sound.play(MediaActionSound.START_VIDEO_RECORDING)
        recording = true
        rec = pr.start(ContextCompat.getMainExecutor(this)) { ev ->
            when (ev) {
                is VideoRecordEvent.Start -> onRecStarted()
                is VideoRecordEvent.Status -> recPill.text = fmtTime(ev.recordingStats.recordedDurationNanos)
                is VideoRecordEvent.Finalize -> onRecStopped(!ev.hasError(), ev.outputResults.outputUri)
                else -> {}
            }
        }
        updateShutter(true)
    }

    private fun stopRecording() {
        sound.play(MediaActionSound.STOP_VIDEO_RECORDING)
        rec?.stop(); rec = null
    }

    private fun fmtTime(nanos: Long): String {
        val s = nanos / 1_000_000_000L
        return String.format(Locale.US, "%02d:%02d", s / 60, s % 60)
    }

    private fun onRecStarted() {
        recPill.text = "00:00"; recPill.visibility = View.VISIBLE; chevBtn.visibility = View.INVISIBLE
        recPill.animate().alpha(1f).start()
        for (t in modeTv) t.animate().alpha(.3f).setDuration(200).start()
    }

    private fun onRecStopped(ok: Boolean, uri: Uri) {
        recording = false
        recPill.visibility = View.GONE; chevBtn.visibility = View.VISIBLE
        for (t in modeTv) t.animate().alpha(1f).setDuration(200).start()
        updateShutter(true)
        if (!ok) { toast("Recording failed"); return }
        io.execute {
            try {
                val bmp = contentResolver.loadThumbnail(uri, Size(600, 600), null)
                runOnUiThread { lastUri = uri; lastIsVideo = true; lastView = bmp; popThumb(scaled(bmp, 220)) }
            } catch (_: Exception) {}
        }
    }

    // ── photo
    private fun capture() {
        val ic = imageCapture ?: run { busy = false; return }
        val ex = extra; val sq = square; val k = lookK(); val flt = filters[fIdx]
        sound.play(MediaActionSound.SHUTTER_CLICK)
        flashV.alpha = 1f; flashV.animate().alpha(0f).setDuration(200).start()
        ic.takePicture(io, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                try {
                    val rot = image.imageInfo.rotationDegrees
                    val out = finish(prepare(image, rot, ex, sq), k, ex, flt)
                    val uri = save(out)
                    val tb = scaled(out, 220); val vb = scaled(out, 2000)
                    runOnUiThread { lastUri = uri; lastIsVideo = false; lastView = vb; popThumb(tb) }
                } catch (e: Throwable) {
                    runOnUiThread { toast("Capture failed") }
                } finally { image.close(); busy = false }
            }
            override fun onError(e: ImageCaptureException) { busy = false; runOnUiThread { toast("Capture failed: ${e.message}") } }
        })
    }

    private fun scaled(b: Bitmap, maxSide: Int): Bitmap {
        val r = maxSide.toFloat() / max(b.width, b.height)
        return if (r >= 1f) b else Bitmap.createScaledBitmap(b, (b.width * r).toInt(), (b.height * r).toInt(), true)
    }

    private fun curve(x: Float, k: Float): Float {
        var y = .025f * k + (1f - .025f * k) * x
        y += .16f * k * (y - .5f) * (1f - abs(2f * y - 1f))
        if (y > .78f) y = .78f + (y - .78f) * (1f - .22f * k)
        return y.coerceIn(0f, 1f)
    }

    private fun cropRect(sw: Int, sh: Int, rot: Int, ex: Float, sq: Boolean): Rect {
        val rotated = rot % 180 != 0
        val uw = (if (rotated) sh else sw).toFloat(); val uh = (if (rotated) sw else sh).toFloat()
        var cw = uw / ex; var ch = uh / ex
        if (sq) { val s = min(cw, ch); cw = s; ch = s }
        val cwS = (if (rotated) ch else cw).roundToInt().coerceIn(2, sw)
        val chS = (if (rotated) cw else ch).roundToInt().coerceIn(2, sh)
        val sx = (sw - cwS) / 2; val sy = (sh - chS) / 2
        return Rect(sx, sy, sx + cwS, sy + chS)
    }

    /** يفكّ ترميز المنطقة المقصوصة فقط من الـ JPEG الكامل فيبقى كل التفصيل الحقيقي */
    private fun prepare(image: ImageProxy, rot: Int, ex: Float, sq: Boolean): Bitmap {
        val m = Matrix().apply { postRotate(rot.toFloat()) }
        if (image.format == ImageFormat.JPEG) {
            val buf = image.planes[0].buffer
            val bytes = ByteArray(buf.remaining()); buf.get(bytes)
            @Suppress("DEPRECATION")
            val dec = BitmapRegionDecoder.newInstance(bytes, 0, bytes.size, false)
            try {
                val r = cropRect(dec.width, dec.height, rot, ex, sq)
                var s = 1
                while (r.width().toLong() * r.height() / (s * s) > 30_000_000L) s *= 2
                val opts = BitmapFactory.Options().apply { inSampleSize = s; inPreferredConfig = Bitmap.Config.ARGB_8888 }
                val part = dec.decodeRegion(r, opts)
                return Bitmap.createBitmap(part, 0, 0, part.width, part.height, m, true)
            } finally { dec.recycle() }
        }
        val src = image.toBitmap()
        val r = cropRect(src.width, src.height, rot, ex, sq)
        return Bitmap.createBitmap(src, r.left, r.top, r.width(), r.height(), m, true)
    }

    /** رفع دقة تدريجي + شحذ تكيّفي + طابع الأيفون + الفلتر المختار */
    private fun finish(b0: Bitmap, k: Float, ex: Float, flt: Flt): Bitmap {
        var b = b0
        val px = b.width.toLong() * b.height
        if (px > 13_000_000L) {
            val f = sqrt(12_500_000.0 / px).toFloat()
            b = Bitmap.createScaledBitmap(b, (b.width * f).toInt(), (b.height * f).toInt(), true)
        }
        val longSide = max(b.width, b.height)
        var up = 1f
        if (longSide < 3600) {
            up = 4000f / longSide
            val tw = (b.width * up).roundToInt(); val th = (b.height * up).roundToInt()
            var cur = b
            while (max(cur.width, cur.height) * 2 <= max(tw, th)) cur = Bitmap.createScaledBitmap(cur, cur.width * 2, cur.height * 2, true)
            if (cur.width != tw) cur = Bitmap.createScaledBitmap(cur, tw, th, true)
            b = cur
        }
        if (!b.isMutable) b = b.copy(Bitmap.Config.ARGB_8888, true)
        val amount = if (up > 1f) (.55f + .3f * ln(up) / ln(2f)).coerceAtMost(1.5f) else if (ex > 1.2f) .5f else .25f
        sharpen(b, amount, if (up > 1f) 7f else 4f)
        if (k > 0f) applyLook(b, k)
        return applyFilter(b, flt)
    }

    private fun applyFilter(src: Bitmap, f: Flt): Bitmap {
        if (f.m == null && f.vig <= 0f) return src
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val p = Paint(Paint.FILTER_BITMAP_FLAG)
        f.m?.let { p.colorFilter = ColorMatrixColorFilter(it) }
        c.drawBitmap(src, 0f, 0f, p)
        if (f.vig > 0f) {
            val vp = Paint()
            val r = hypot(out.width.toFloat(), out.height.toFloat()) / 2f
            vp.shader = RadialGradient(out.width / 2f, out.height / 2f, r, intArrayOf(0, 0, ((f.vig * 255).toInt() shl 24)),
                floatArrayOf(0f, .55f, 1f), Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, out.width.toFloat(), out.height.toFloat(), vp)
        }
        return out
    }

    private fun sharpen(bmp: Bitmap, amount: Float, thr: Float) {
        val w = bmp.width; val h = bmp.height
        val rows = 128
        val buf = IntArray(w * (rows + 2)); val lum = IntArray(w * (rows + 2))
        var y = 0
        while (y < h) {
            val n = min(rows, h - y)
            val y0 = max(0, y - 1); val y1 = min(h, y + n + 1); val rc = y1 - y0
            bmp.getPixels(buf, 0, w, 0, y0, w, rc)
            for (i in 0 until w * rc) {
                val p = buf[i]
                lum[i] = (((p shr 16) and 255) * 77 + ((p shr 8) and 255) * 150 + (p and 255) * 29) shr 8
            }
            val out = IntArray(w * n)
            for (r in 0 until n) {
                val ry = y + r - y0
                val ru = if (y + r > 0) ry - 1 else ry
                val rd = if (y + r < h - 1) ry + 1 else ry
                val bu = ru * w; val bc = ry * w; val bd = rd * w
                for (x in 0 until w) {
                    val xl = if (x > 0) x - 1 else x; val xr = if (x < w - 1) x + 1 else x
                    val blur = (4 * lum[bc + x] + 2 * (lum[bu + x] + lum[bd + x] + lum[bc + xl] + lum[bc + xr]) +
                        lum[bu + xl] + lum[bu + xr] + lum[bd + xl] + lum[bd + xr]) / 16f
                    val d = lum[bc + x] - blur
                    val ad = abs(d)
                    var e = if (ad < thr) d * (ad / thr) else d
                    e = (e * amount).coerceIn(-45f, 45f)
                    val ei = e.roundToInt()
                    val p = buf[bc + x]
                    val nr = (((p shr 16) and 255) + ei).coerceIn(0, 255)
                    val ng = (((p shr 8) and 255) + ei).coerceIn(0, 255)
                    val nb = ((p and 255) + ei).coerceIn(0, 255)
                    out[r * w + x] = (p and 0xFF000000.toInt()) or (nr shl 16) or (ng shl 8) or nb
                }
            }
            bmp.setPixels(out, 0, w, 0, y, w, n)
            y += n
        }
    }

    private fun applyLook(bmp: Bitmap, k: Float) {
        val w = bmp.width; val h = bmp.height
        val lut = IntArray(256) { (curve(it / 255f, k) * 255f + .5f).toInt() }
        val wr = 1f + .025f * k; val wb = 1f - .035f * k; val sat = 1f - .06f * k
        val rows = 256; val buf = IntArray(w * rows)
        fun cl(f: Float) = if (f < 0f) 0 else if (f > 255f) 255 else f.toInt()
        var y = 0
        while (y < h) {
            val n = min(rows, h - y)
            bmp.getPixels(buf, 0, w, 0, y, w, n)
            for (i in 0 until w * n) {
                val px = buf[i]
                var r = ((px shr 16) and 255) * wr; var g = ((px shr 8) and 255).toFloat(); var b = (px and 255) * wb
                val l = .299f * r + .587f * g + .114f * b
                r = l + (r - l) * sat; g = l + (g - l) * sat; b = l + (b - l) * sat
                buf[i] = (px and 0xFF000000.toInt()) or (lut[cl(r)] shl 16) or (lut[cl(g)] shl 8) or lut[cl(b)]
            }
            bmp.setPixels(buf, 0, w, 0, y, w, n)
            y += n
        }
    }

    private fun save(bmp: Bitmap): Uri? {
        val name = "IMG_${System.currentTimeMillis()}.jpg"
        val cv = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/iCam")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv) ?: return null
        contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
        cv.clear(); cv.put(MediaStore.Images.Media.IS_PENDING, 0)
        contentResolver.update(uri, cv, null, null)
        return uri
    }

    private fun popThumb(tb: Bitmap) {
        thumb.setImageBitmap(tb)
        thumb.scaleX = .4f; thumb.scaleY = .4f
        thumb.animate().scaleX(1f).scaleY(1f).setDuration(420).setInterpolator(OvershootInterpolator(2.4f)).start()
    }

    // ───────────────────────── gallery thumbnail on launch
    private fun latestOf(base: Uri, path: String): Pair<Uri, Long>? {
        contentResolver.query(base, arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DATE_ADDED),
            "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?", arrayOf("$path%"),
            "${MediaStore.MediaColumns.DATE_ADDED} DESC")?.use { c ->
            if (c.moveToFirst()) return Pair(ContentUris.withAppendedId(base, c.getLong(0)), c.getLong(1))
        }
        return null
    }
    private fun loadLatest() {
        io.execute {
            try {
                val img = latestOf(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "Pictures/iCam")
                val vid = latestOf(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, "Movies/iCam")
                val best = listOfNotNull(img?.let { Triple(it.first, it.second, false) }, vid?.let { Triple(it.first, it.second, true) })
                    .maxByOrNull { it.second } ?: return@execute
                val bmp = contentResolver.loadThumbnail(best.first, Size(1600, 1600), null)
                runOnUiThread {
                    if (lastUri == null) { lastUri = best.first; lastIsVideo = best.third; lastView = bmp; thumb.setImageBitmap(scaled(bmp, 220)) }
                }
            } catch (_: Exception) {}
        }
    }

    // ───────────────────────── viewer
    private fun openViewer() {
        val u = lastUri ?: return
        if (lastIsVideo) {
            try {
                startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(u, "video/mp4").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
            } catch (_: Exception) { toast("No video player found") }
            return
        }
        val b = lastView ?: return
        viewerImg.setImageBitmap(b)
        val loc = IntArray(2); thumb.getLocationOnScreen(loc)
        viewerImg.pivotX = loc[0] + thumb.width / 2f; viewerImg.pivotY = loc[1] + thumb.height / 2f
        viewer.visibility = View.VISIBLE; viewer.alpha = 0f; viewerImg.scaleX = .2f; viewerImg.scaleY = .2f
        viewer.animate().alpha(1f).setDuration(240).start()
        viewerImg.animate().scaleX(1f).scaleY(1f).setDuration(340).setInterpolator(DecelerateInterpolator(1.7f)).start()
    }
    private fun closeViewer() {
        viewerImg.animate().scaleX(.2f).scaleY(.2f).setDuration(260).setInterpolator(DecelerateInterpolator()).start()
        viewer.animate().alpha(0f).setDuration(260).withEndAction { viewer.visibility = View.GONE }.start()
    }
    private fun shareLast() {
        val u = lastUri ?: return
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "image/jpeg"; putExtra(Intent.EXTRA_STREAM, u); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }, "Share"))
    }
}
