package com.icam.app

import android.Manifest
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCharacteristics
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.*
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.core.CameraFilter
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.math.*

data class Lens(val id: String, val f: Float)

class MainActivity : ComponentActivity() {
    private val Y = 0xFFFFD60A.toInt()
    private val GLASS = 0x9946463A.toInt()
    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private val MAXZ = 100f

    // views
    private lateinit var root: FrameLayout
    private lateinit var box: FrameLayout
    private lateinit var previewView: PreviewView
    private lateinit var touch: View
    private lateinit var gridV: View
    private lateinit var focusV: View
    private lateinit var flashV: View
    private lateinit var countT: TextView
    private lateinit var readout: TextView
    private lateinit var zoomPill: ScrubLinear
    private lateinit var lookPanel: LinearLayout
    private lateinit var toolsPanel: LinearLayout
    private lateinit var topBar: LinearLayout
    private lateinit var bottomCol: LinearLayout
    private lateinit var thumb: ImageView
    private lateinit var flipBtn: View
    private lateinit var flashIcon: IconView
    private lateinit var lookIcon: IconView
    private lateinit var lookSeek: SeekBar
    private lateinit var lookVal: TextView
    private lateinit var hiLite: View
    private lateinit var modesRow: LinearLayout
    private lateinit var tvSquare: TextView
    private lateinit var tvPhoto: TextView
    private lateinit var viewer: FrameLayout
    private lateinit var viewerImg: ImageView
    private lateinit var timerLabel: TextView
    private lateinit var gridBtn: LinearLayout
    private lateinit var timerBtn: LinearLayout
    private lateinit var fBtn: FrameLayout
    private lateinit var dotsBtn: FrameLayout
    private var insetTop = 0
    private var insetBottom = 0

    // camera state
    private var provider: ProcessCameraProvider? = null
    private var cam: androidx.camera.core.Camera? = null
    private var imageCapture: ImageCapture? = null
    private var front = false
    private var lenses = listOf<Lens>()
    private var curLens: Lens? = null
    private var hwMin = 1f
    private var hwMax = 1f
    private var zoom = 1f
    private var extra = 1f
    private var switching = false
    @Volatile private var busy = false
    private var levels = listOf(1f)
    private var levelViews = listOf<TextView>()
    private var zoomAnim: ValueAnimator? = null
    private var scrubZ0 = 1f

    // options
    private var square = false
    private var lookOn = true
    private var flashOn = false
    private var gridOn = false
    private var timerSec = 0
    private var hiRes = true
    private var lastUri: Uri? = null
    private var lastView: Bitmap? = null
    private var boxAnim: ValueAnimator? = null

    private val permReq = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startCamera() else toast("Camera permission is required")
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun dpf(v: Float) = v * resources.displayMetrics.density
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun haptic() { root.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK) }
    private fun oval(c: Int) = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(c) }
    private fun rr(c: Int, r: Float) = GradientDrawable().apply { shape = GradientDrawable.RECTANGLE; cornerRadius = r; setColor(c) }
    private fun fl(w: Int, h: Int, g: Int = Gravity.NO_GRAVITY) = FrameLayout.LayoutParams(w, h, g)
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private fun label(t: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color); gravity = Gravity.CENTER
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun bounce(v: View, onClick: () -> Unit) {
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN ->
                    view.animate().scaleX(.86f).scaleY(.86f).setDuration(90).setInterpolator(DecelerateInterpolator()).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    view.animate().scaleX(1f).scaleY(1f).setDuration(280).setInterpolator(OvershootInterpolator(3.2f)).start()
                    if (e.actionMasked == MotionEvent.ACTION_UP && e.x in 0f..view.width.toFloat() && e.y in 0f..view.height.toFloat()) {
                        haptic(); onClick()
                    }
                }
            }
            true
        }
    }

    private fun glass(size: Int, child: View, csize: Int): FrameLayout = FrameLayout(this).apply {
        background = oval(GLASS)
        addView(child, fl(csize, csize, Gravity.CENTER))
        layoutParams = fl(size, size)
    }

    // ───────────────────────── onCreate
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        buildUi()
        setContentView(root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { _, ins ->
            val s = ins.getInsets(WindowInsetsCompat.Type.systemBars())
            insetTop = s.top; insetBottom = s.bottom; layoutAll(); ins
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
            startCamera() else permReq.launch(Manifest.permission.CAMERA)
    }

    override fun onDestroy() { super.onDestroy(); io.shutdown() }

    private fun layoutAll() {
        (box.layoutParams as FrameLayout.LayoutParams).topMargin = insetTop + dp(52)
        box.requestLayout()
        (topBar.layoutParams as FrameLayout.LayoutParams).topMargin = insetTop
        topBar.requestLayout()
        bottomCol.setPadding(0, 0, 0, insetBottom + dp(8))
    }

    // ───────────────────────── UI
    @SuppressLint("ClickableViewAccessibility")
    private fun buildUi() {
        val sw = resources.displayMetrics.widthPixels
        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }

        // top bar
        flashIcon = IconView(this, "bolt").apply { slashed = true }
        lookIcon = IconView(this, "look").apply { tint = Y }
        val flashW = FrameLayout(this).apply { addView(flashIcon, fl(dp(24), dp(24), Gravity.CENTER)) }
        val lookW = FrameLayout(this).apply { addView(lookIcon, fl(dp(26), dp(26), Gravity.CENTER)) }
        topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            addView(flashW, LinearLayout.LayoutParams(dp(48), dp(48)))
            addView(View(context), LinearLayout.LayoutParams(dp(30), 1))
            addView(lookW, LinearLayout.LayoutParams(dp(48), dp(48)))
        }
        bounce(flashW) { toggleFlash() }
        bounce(lookW) { lookOn = !lookOn; lookIcon.tint = if (lookOn) Y else Color.WHITE; applyLookPreview(); toast(if (lookOn) "Look on" else "Look off") }

        // viewfinder
        box = FrameLayout(this).apply { clipChildren = true; setBackgroundColor(0xFF111111.toInt()) }
        previewView = PreviewView(this).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
        box.addView(previewView, fl(MATCH, MATCH))
        gridV = object : View(this) {
            val gp = Paint().apply { color = 0x66FFFFFF; strokeWidth = dpf(1f) }
            override fun onDraw(c: Canvas) {
                for (i in 1..2) {
                    c.drawLine(width * i / 3f, 0f, width * i / 3f, height.toFloat(), gp)
                    c.drawLine(0f, height * i / 3f, width.toFloat(), height * i / 3f, gp)
                }
            }
        }.apply { alpha = 0f }
        box.addView(gridV, fl(MATCH, MATCH))
        touch = View(this)
        box.addView(touch, fl(MATCH, MATCH))
        focusV = View(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.RECTANGLE; setStroke(dp(2), Y); setColor(0) }
            alpha = 0f
        }
        box.addView(focusV, fl(dp(76), dp(76)))
        flashV = View(this).apply { setBackgroundColor(Color.BLACK); alpha = 0f }
        box.addView(flashV, fl(MATCH, MATCH))
        countT = label("", 96f).apply { typeface = Typeface.create("sans-serif-thin", Typeface.NORMAL); visibility = View.GONE }
        box.addView(countT, fl(MATCH, MATCH))

        // zoom pill + readout
        readout = label("1×", 14f, Y, true).apply {
            background = rr(0x99000000.toInt(), dpf(20f)); setPadding(dp(12), dp(5), dp(12), dp(5)); alpha = 0f
        }
        box.addView(readout, fl(WRAP, WRAP, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(66) })
        zoomPill = ScrubLinear(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = rr(0x66000000, dpf(40f)); setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        box.addView(zoomPill, fl(WRAP, WRAP, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(14) })
        zoomPill.onStart = { zoomAnim?.cancel(); scrubZ0 = zoom }
        zoomPill.onMove = { dx ->
            applyZoom(scrubZ0 * exp(dx / (resources.displayMetrics.widthPixels * .45f) * ln(10f))); showReadout()
        }

        // panels
        lookSeek = SeekBar(this).apply {
            max = 100; progress = 80
            progressTintList = ColorStateList.valueOf(Y); thumbTintList = ColorStateList.valueOf(Y)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) { lookVal.text = "$p"; applyLookPreview() }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        lookVal = label("80", 14f)
        lookPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = rr(0xDD28282A.toInt(), dpf(18f))
            setPadding(dp(18), dp(12), dp(18), dp(10)); visibility = View.GONE
            val head = LinearLayout(context).apply {
                addView(label("Look", 14f, Color.WHITE, true), LinearLayout.LayoutParams(0, WRAP, 1f).apply { })
                addView(lookVal)
            }
            addView(head, LinearLayout.LayoutParams(MATCH, WRAP))
            addView(lookSeek, LinearLayout.LayoutParams(MATCH, WRAP))
        }
        box.addView(lookPanel, fl(MATCH, WRAP, Gravity.BOTTOM).apply { setMargins(dp(14), 0, dp(14), dp(72)) })

        fun toolBtn(icon: String, text: String): LinearLayout {
            val tl = label(text, 12f)
            timerLabel = if (icon == "timer") tl else (if (::timerLabel.isInitialized) timerLabel else tl)
            return LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
                background = rr(0x22FFFFFF, dpf(12f)); setPadding(0, dp(10), 0, dp(8))
                addView(IconView(context, icon), LinearLayout.LayoutParams(dp(26), dp(26)))
                addView(tl)
            }
        }
        gridBtn = toolBtn("grid", "Grid")
        timerBtn = toolBtn("timer", "Timer off")
        val hrBtn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            background = rr(0x44FFD60A, dpf(12f)); setPadding(0, dp(10), 0, dp(8))
            addView(label("HR", 17f, Y, true), LinearLayout.LayoutParams(WRAP, dp(26)))
            addView(label("Hi-Res", 12f))
        }
        bounce(hrBtn) {
            hiRes = !hiRes
            hrBtn.background = rr(if (hiRes) 0x44FFD60A else 0x22FFFFFF, dpf(12f))
            toast(if (hiRes) "Hi-Res on (max sensor detail)" else "Hi-Res off (faster)")
            bind(curLens)
        }
        toolsPanel = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; background = rr(0xDD28282A.toInt(), dpf(18f))
            setPadding(dp(10), dp(10), dp(10), dp(10)); visibility = View.GONE
            addView(gridBtn, LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = dp(8) })
            addView(timerBtn, LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = dp(8) })
            addView(hrBtn, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        box.addView(toolsPanel, fl(MATCH, WRAP, Gravity.BOTTOM).apply { setMargins(dp(14), 0, dp(14), dp(72)) })
        bounce(gridBtn) {
            gridOn = !gridOn; gridV.animate().alpha(if (gridOn) 1f else 0f).setDuration(220).start()
            gridBtn.background = rr(if (gridOn) 0x44FFD60A else 0x22FFFFFF, dpf(12f))
        }
        bounce(timerBtn) {
            timerSec = when (timerSec) { 0 -> 3; 3 -> 10; else -> 0 }
            timerLabel.text = if (timerSec == 0) "Timer off" else "Timer ${timerSec}s"
            timerBtn.background = rr(if (timerSec > 0) 0x44FFD60A else 0x22FFFFFF, dpf(12f))
        }

        // bottom controls
        fBtn = FrameLayout(this).apply {
            background = oval(GLASS)
            addView(label("ƒ", 26f).apply { typeface = Typeface.create(Typeface.SERIF, Typeface.ITALIC) }, fl(MATCH, MATCH))
        }
        bounce(fBtn) { showPanel(lookPanel) }
        val shutterDisc = View(this).apply { background = oval(Color.WHITE) }
        val shutter = FrameLayout(this).apply {
            background = oval(GLASS); addView(shutterDisc, fl(dp(68), dp(68), Gravity.CENTER))
        }
        bounce(shutter) { shoot() }
        dotsBtn = FrameLayout(this).apply { background = oval(GLASS); addView(IconView(context, "dots"), fl(dp(28), dp(28), Gravity.CENTER)) }
        bounce(dotsBtn) { showPanel(toolsPanel) }
        val row1 = FrameLayout(this).apply {
            addView(fBtn, fl(dp(54), dp(54), Gravity.START or Gravity.CENTER_VERTICAL).apply { marginStart = dp(40) })
            addView(shutter, fl(dp(82), dp(82), Gravity.CENTER))
            addView(dotsBtn, fl(dp(54), dp(54), Gravity.END or Gravity.CENTER_VERTICAL).apply { marginEnd = dp(40) })
        }

        thumb = ImageView(this).apply {
            background = oval(0xFF2A2A2C.toInt()); scaleType = ImageView.ScaleType.CENTER_CROP
            outlineProvider = ViewOutlineProvider.BACKGROUND; clipToOutline = true
        }
        bounce(thumb) { openViewer() }
        tvSquare = label("SQUARE", 13f, Color.WHITE, true).apply { setPadding(dp(16), dp(9), dp(16), dp(9)); letterSpacing = .04f }
        tvPhoto = label("PHOTO", 13f, Y, true).apply { setPadding(dp(16), dp(9), dp(16), dp(9)); letterSpacing = .04f }
        modesRow = LinearLayout(this).apply { addView(tvSquare); addView(tvPhoto) }
        hiLite = View(this).apply { background = rr(0xAA6A6A30.toInt(), dpf(22f)) }
        val modes = FrameLayout(this).apply {
            addView(hiLite, fl(WRAP, WRAP)); addView(modesRow, fl(WRAP, WRAP))
        }
        tvSquare.setOnClickListener { setMode(true) }
        tvPhoto.setOnClickListener { setMode(false) }
        flipBtn = FrameLayout(this).apply { background = oval(GLASS); addView(IconView(context, "flip"), fl(dp(30), dp(30), Gravity.CENTER)) }
        bounce(flipBtn) { flipCamera() }
        val row2 = FrameLayout(this).apply {
            addView(thumb, fl(dp(54), dp(54), Gravity.START or Gravity.CENTER_VERTICAL).apply { marginStart = dp(22) })
            addView(modes, fl(WRAP, WRAP, Gravity.CENTER))
            addView(flipBtn, fl(dp(54), dp(54), Gravity.END or Gravity.CENTER_VERTICAL).apply { marginEnd = dp(22) })
        }
        bottomCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(row1, LinearLayout.LayoutParams(MATCH, dp(96)))
            addView(row2, LinearLayout.LayoutParams(MATCH, dp(66)))
        }

        // viewer
        viewerImg = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
        val done = label("Done", 17f, 0xFF0A84FF.toInt()).apply { setPadding(dp(24), dp(14), dp(24), dp(14)) }
        val share = label("Share", 17f, 0xFF0A84FF.toInt()).apply { setPadding(dp(24), dp(14), dp(24), dp(14)) }
        done.setOnClickListener { closeViewer() }
        share.setOnClickListener { shareLast() }
        viewer = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK); visibility = View.GONE; isClickable = true
            addView(viewerImg, fl(MATCH, MATCH).apply { topMargin = dp(40); bottomMargin = dp(70) })
            addView(done, fl(WRAP, WRAP, Gravity.BOTTOM or Gravity.START).apply { bottomMargin = dp(16) })
            addView(share, fl(WRAP, WRAP, Gravity.BOTTOM or Gravity.END).apply { bottomMargin = dp(16) })
        }

        root.addView(box, fl(MATCH, sw * 4 / 3, Gravity.TOP).apply { topMargin = dp(80) })
        root.addView(topBar, fl(MATCH, dp(52), Gravity.TOP))
        root.addView(bottomCol, fl(MATCH, WRAP, Gravity.BOTTOM))
        root.addView(viewer, fl(MATCH, MATCH))

        // gestures
        val scaleDet = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScaleBegin(d: ScaleGestureDetector): Boolean { zoomAnim?.cancel(); return true }
            override fun onScale(d: ScaleGestureDetector): Boolean { applyZoom(zoom * d.scaleFactor); showReadout(); return true }
        })
        val tapDet = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onSingleTapUp(e: MotionEvent): Boolean { focusAt(e.x, e.y); return true }
        })
        touch.setOnTouchListener { _, e ->
            scaleDet.onTouchEvent(e)
            if (!scaleDet.isInProgress && e.pointerCount == 1) tapDet.onTouchEvent(e)
            true
        }
        modes.post { moveHi(tvPhoto, false) }
        previewView.previewStreamState.observe(this) {
            if (it == PreviewView.StreamState.STREAMING) {
                previewView.animate().alpha(1f).setDuration(200).start(); applyLookPreview()
            }
        }
    }

    // ───────────────────────── panels / modes / animations
    private fun showPanel(p: View) {
        fBtn.background = oval(if (p === lookPanel && p.visibility != View.VISIBLE) 0x66FFD60A else GLASS)
        for (v in listOf(lookPanel, toolsPanel)) {
            if (v === p && v.visibility != View.VISIBLE) {
                v.visibility = View.VISIBLE; v.alpha = 0f; v.translationY = dpf(24f)
                v.animate().alpha(1f).translationY(0f).setDuration(240).setInterpolator(DecelerateInterpolator()).start()
            } else if (v.visibility == View.VISIBLE) {
                v.animate().alpha(0f).translationY(dpf(24f)).setDuration(180).withEndAction { v.visibility = View.GONE }.start()
            }
        }
        if (p !== lookPanel || lookPanel.visibility == View.VISIBLE) fBtn.background = oval(GLASS)
    }

    private fun moveHi(t: TextView, animate: Boolean) {
        val lp = hiLite.layoutParams
        if (!animate) {
            lp.width = t.width; lp.height = t.height; hiLite.layoutParams = lp; hiLite.x = t.left.toFloat(); return
        }
        ValueAnimator.ofInt(lp.width, t.width).apply {
            duration = 300; interpolator = DecelerateInterpolator()
            addUpdateListener { lp.width = it.animatedValue as Int; hiLite.layoutParams = lp }
            start()
        }
        hiLite.animate().x(t.left.toFloat()).setDuration(300).setInterpolator(DecelerateInterpolator()).start()
    }

    private fun setMode(sq: Boolean) {
        if (sq == square) return
        square = sq
        tvSquare.setTextColor(if (sq) Y else Color.WHITE); tvPhoto.setTextColor(if (sq) Color.WHITE else Y)
        moveHi(if (sq) tvSquare else tvPhoto, true); haptic()
        val w = resources.displayMetrics.widthPixels
        val lp = box.layoutParams
        boxAnim?.cancel()
        boxAnim = ValueAnimator.ofInt(lp.height, if (sq) w else w * 4 / 3).apply {
            duration = 340; interpolator = DecelerateInterpolator(1.4f)
            addUpdateListener { lp.height = it.animatedValue as Int; box.layoutParams = lp }
            start()
        }
    }

    private fun showReadout() {
        readout.text = fmt(zoom) + "×"
        readout.animate().alpha(1f).setDuration(80).start()
        main.removeCallbacks(hideReadout); main.postDelayed(hideReadout, 900)
    }
    private val hideReadout = Runnable { readout.animate().alpha(0f).setDuration(300).start() }

    private fun fmt(z: Float) = if (abs(z - z.roundToInt()) < .05f) "${z.roundToInt()}" else String.format(Locale.US, "%.1f", z)

    // ───────────────────────── look (live preview)
    private fun lookK() = if (lookOn) lookSeek.progress / 100f else 0f

    private fun findTexture(v: View): TextureView? {
        if (v is TextureView) return v
        if (v is ViewGroup) for (i in 0 until v.childCount) findTexture(v.getChildAt(i))?.let { return it }
        return null
    }
    private fun applyLookPreview(retries: Int = 6) {
        val t = findTexture(previewView)
        if (t == null) { if (retries > 0) main.postDelayed({ applyLookPreview(retries - 1) }, 200); return }
        val k = lookK()
        val paint = Paint()
        if (k > 0f) {
            val sat = ColorMatrix().apply { setSaturation(1f - .07f * k) }
            val c = 1f + .05f * k
            val tt = 128f * (1f - c) + 6f * k
            val cm = ColorMatrix(floatArrayOf(
                c * (1f + .025f * k), 0f, 0f, 0f, tt,
                0f, c, 0f, 0f, tt,
                0f, 0f, c * (1f - .035f * k), 0f, tt,
                0f, 0f, 0f, 1f, 0f))
            val m = ColorMatrix(); m.postConcat(sat); m.postConcat(cm)
            paint.colorFilter = ColorMatrixColorFilter(m)
        }
        t.setLayerPaint(paint)
    }

    // ───────────────────────── camera
    private fun startCamera() {
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            provider = f.get(); discoverLenses(); buildLevels()
            bind(lenses.firstOrNull { abs(it.f - 1f) < .12f })
        }, ContextCompat.getMainExecutor(this))
    }

    /** يكتشف عدسات الخلفية ويحسب الزوم المكافئ لكل واحدة نسبةً للعدسة الرئيسية */
    private fun discoverLenses() {
        val p = provider ?: return
        val raw = ArrayList<Pair<String, Float>>()
        for (info in p.availableCameraInfos) {
            try {
                val c2 = Camera2CameraInfo.from(info)
                if (c2.getCameraCharacteristic(CameraCharacteristics.LENS_FACING) != CameraCharacteristics.LENS_FACING_BACK) continue
                val fl = c2.getCameraCharacteristic(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.firstOrNull() ?: continue
                val sz = c2.getCameraCharacteristic(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE) ?: continue
                raw.add(Pair(c2.cameraId, fl * 43.27f / hypot(sz.width, sz.height)))
            } catch (_: Exception) {}
        }
        if (raw.isEmpty()) { lenses = emptyList(); return }
        val mainEq = raw.minByOrNull { abs(it.second - 24f) }!!
        val res = mutableListOf(Lens(mainEq.first, 1f))
        for (o in raw.sortedBy { it.second }) {
            val f = o.second / mainEq.second
            if (o.first != mainEq.first && f in .4f..12f && res.none { abs(it.f / f - 1f) < .12f }) res.add(Lens(o.first, f))
        }
        lenses = res.sortedBy { it.f }
    }

    private fun bind(lens: Lens?) {
        val p = provider ?: return
        p.unbindAll()
        curLens = lens
        val selector = when {
            front -> CameraSelector.DEFAULT_FRONT_CAMERA
            lens != null -> CameraSelector.Builder().requireLensFacing(CameraSelector.LENS_FACING_BACK)
                .addCameraFilter(CameraFilter { infos ->
                    infos.filter { try { Camera2CameraInfo.from(it).cameraId == lens.id } catch (e: Exception) { false } }
                }).build()
            else -> CameraSelector.DEFAULT_BACK_CAMERA
        }
        val rs = ResolutionSelector.Builder().setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY).build()
        val capRs = ResolutionSelector.Builder().setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY)
            .setResolutionStrategy(ResolutionStrategy.HIGHEST_AVAILABLE_STRATEGY)
            .apply { if (hiRes) setAllowedResolutionMode(ResolutionSelector.PREFER_HIGHER_RESOLUTION_OVER_CAPTURE_RATE) }.build()
        val preview = Preview.Builder().setResolutionSelector(rs).build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
        val ic = ImageCapture.Builder().setResolutionSelector(capRs)
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
            .setFlashMode(if (flashOn) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF).build()
        try {
            cam = p.bindToLifecycle(this, selector, preview, ic)
            imageCapture = ic
        } catch (e: Exception) {
            if (!front && lens != null) {
                lenses = lenses.filter { it.id != lens.id }
                buildLevels()
                bind(lenses.firstOrNull { abs(it.f - 1f) < .12f }); return
            }
            previewView.animate().alpha(1f).start(); toast("Camera error: ${e.message}"); return
        }
        var seen = false
        cam!!.cameraInfo.zoomState.observe(this) { zs ->
            if (!seen || abs(zs.minZoomRatio - hwMin) > .01f || abs(zs.maxZoomRatio - hwMax) > .01f) {
                seen = true; hwMin = zs.minZoomRatio; hwMax = zs.maxZoomRatio; applyZoom(zoom)
            }
        }
    }

    private fun minTotal() = if (front || lenses.isEmpty()) 1f else lenses.first().f

    private fun applyZoom(z0: Float) {
        val z = z0.coerceIn(minTotal(), MAXZ)
        if (!front && lenses.size > 1 && !switching) {
            val want = lenses.lastOrNull { it.f <= z * 1.12f } ?: lenses.first()
            if (want.id != curLens?.id) {
                zoom = z; switching = true
                previewView.animate().alpha(.15f).setDuration(90).start()
                main.postDelayed({ bind(want); switching = false }, 100)
                return
            }
        }
        val f = if (front) 1f else (curLens?.f ?: 1f)
        val req = z / f
        val hw = req.coerceIn(hwMin, hwMax)
        extra = if (req > hw) req / hw else 1f
        zoom = max(hw * f * extra, minTotal())
        cam?.cameraControl?.setZoomRatio(hw)
        previewView.scaleX = extra; previewView.scaleY = extra
        refreshZoomUi()
    }

    private fun animateZoom(target: Float) {
        zoomAnim?.cancel()
        val z0 = zoom
        val dur = 380L + (260 * abs(log10(max(target, .1f) / max(z0, .1f)))).toLong()
        zoomAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = dur; interpolator = DecelerateInterpolator(1.5f)
            addUpdateListener { applyZoom(z0 * (target / z0).pow(it.animatedValue as Float)); showReadout() }
            start()
        }
    }

    private fun buildLevels() {
        val set = sortedSetOf<Float>()
        if (front) { set.add(1f); set.add(2f); set.add(3f) } else {
            for (l in lenses) {
                val f = l.f
                set.add(if (f < 1f) (f * 10).roundToInt() / 10f else if (abs(f - f.roundToInt()) < .3f) f.roundToInt().toFloat() else (f * 10).roundToInt() / 10f)
            }
            set.add(1f); set.add(2f)
            if (lenses.none { it.f >= 4f }) { set.add(5f); set.add(10f) }
            set.add(30f); set.add(100f)
        }
        levels = set.toList()
        zoomPill.removeAllViews()
        levelViews = levels.map { lv ->
            label("", 12f, Color.WHITE, true).apply {
                minWidth = dp(38); minHeight = dp(38)
                setPadding(dp(3), 0, dp(3), 0)
                zoomPill.addView(this, LinearLayout.LayoutParams(WRAP, dp(38)))
                bounce(this) { animateZoom(lv) }
            }
        }
        refreshZoomUi()
    }

    private fun refreshZoomUi() {
        if (levels.isEmpty() || levelViews.size != levels.size) return
        val act = levels.indexOfLast { it <= zoom + .05f }.coerceAtLeast(0)
        for (i in levels.indices) {
            val v = levelViews[i]
            if (i == act) {
                v.text = fmt(zoom) + "×"; v.setTextColor(Y); v.background = oval(0xCC3A3A30.toInt())
                if (v.scaleX < 1.05f && v.animation == null) v.animate().scaleX(1.08f).scaleY(1.08f).setDuration(120).start()
            } else {
                val l = levels[i]
                v.text = if (l < 1f) fmt(l).replace("0.", ".") else fmt(l)
                v.setTextColor(Color.WHITE); v.background = null
                if (v.scaleX > 1f) v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
            }
        }
    }

    private fun flipCamera() {
        front = !front; zoom = 1f; extra = 1f
        flipBtn.animate().rotationBy(180f).setDuration(380).setInterpolator(DecelerateInterpolator()).start()
        previewView.animate().alpha(.1f).scaleX(.96f).scaleY(.96f).setDuration(140).start()
        main.postDelayed({
            previewView.scaleX = 1f; previewView.scaleY = 1f
            buildLevels(); bind(if (front) null else lenses.firstOrNull { abs(it.f - 1f) < .12f })
        }, 150)
    }

    private fun toggleFlash() {
        if (cam?.cameraInfo?.hasFlashUnit() != true) { toast("Flash not available"); return }
        flashOn = !flashOn
        flashIcon.slashed = !flashOn; flashIcon.tint = if (flashOn) Y else Color.WHITE
        imageCapture?.flashMode = if (flashOn) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF
    }

    private fun focusAt(x: Float, y: Float) {
        showPanelsOff()
        try {
            val pt = previewView.meteringPointFactory.createPoint(x, y)
            cam?.cameraControl?.startFocusAndMetering(FocusMeteringAction.Builder(pt).setAutoCancelDuration(3, TimeUnit.SECONDS).build())
        } catch (_: Exception) {}
        focusV.x = x - dp(38); focusV.y = y - dp(38)
        focusV.animate().cancel(); focusV.alpha = 1f; focusV.scaleX = 1.5f; focusV.scaleY = 1.5f
        focusV.animate().scaleX(1f).scaleY(1f).setDuration(220).withEndAction {
            focusV.animate().alpha(0f).setStartDelay(900).setDuration(300).start()
        }.start()
        haptic()
    }
    private fun showPanelsOff() {
        for (v in listOf(lookPanel, toolsPanel)) if (v.visibility == View.VISIBLE)
            v.animate().alpha(0f).translationY(dpf(24f)).setDuration(180).withEndAction { v.visibility = View.GONE }.start()
    }

    // ───────────────────────── capture
    private fun shoot() {
        if (busy || imageCapture == null) return
        busy = true
        if (timerSec > 0) countdown(timerSec) { capture() } else capture()
    }
    private fun countdown(n: Int, done: () -> Unit) {
        if (n == 0) { countT.visibility = View.GONE; done(); return }
        countT.text = "$n"; countT.visibility = View.VISIBLE; countT.alpha = 1f; countT.scaleX = 1.5f; countT.scaleY = 1.5f
        countT.animate().scaleX(1f).scaleY(1f).alpha(.35f).setDuration(900).start()
        main.postDelayed({ countdown(n - 1, done) }, 1000)
    }

    private fun capture() {
        val ic = imageCapture ?: run { busy = false; return }
        val ex = extra; val sq = square; val k = lookK()
        flashV.alpha = 1f; flashV.animate().alpha(0f).setDuration(200).start()
        ic.takePicture(io, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                try {
                    val rot = image.imageInfo.rotationDegrees
                    val out = finish(prepare(image, rot, ex, sq), k, ex)
                    val uri = save(out)
                    val tb = scaled(out, 220); val vb = scaled(out, 2000)
                    runOnUiThread { onSaved(uri, tb, vb) }
                } catch (e: Throwable) {
                    runOnUiThread { toast("Capture failed") }
                } finally { image.close(); busy = false }
            }
            override fun onError(e: ImageCaptureException) { busy = false; runOnUiThread { toast("Capture failed: ${e.message}") } }
        })
    }

    private fun scaled(b: Bitmap, maxSide: Int): Bitmap {
        val r = maxSide.toFloat() / max(b.width, b.height)
        return if (r >= 1f) b else Bitmap.createScaledBitmap(b, (b.width * r).toInt(), (b.height * r).toInt(), true)
    }

    private fun curve(x: Float, k: Float): Float {
        var y = .025f * k + (1f - .025f * k) * x
        y += .16f * k * (y - .5f) * (1f - abs(2f * y - 1f))
        if (y > .78f) y = .78f + (y - .78f) * (1f - .22f * k)
        return y.coerceIn(0f, 1f)
    }

    /** منطقة القص المركزية بإحداثيات الصورة الخام (قبل التدوير) */
    private fun cropRect(sw: Int, sh: Int, rot: Int, ex: Float, sq: Boolean): Rect {
        val rotated = rot % 180 != 0
        val uw = (if (rotated) sh else sw).toFloat(); val uh = (if (rotated) sw else sh).toFloat()
        var cw = uw / ex; var ch = uh / ex
        if (sq) { val s = min(cw, ch); cw = s; ch = s }
        val cwS = (if (rotated) ch else cw).roundToInt().coerceIn(2, sw)
        val chS = (if (rotated) cw else ch).roundToInt().coerceIn(2, sh)
        val sx = (sw - cwS) / 2; val sy = (sh - chS) / 2
        return Rect(sx, sy, sx + cwS, sy + chS)
    }

    /** يفكّ ترميز المنطقة المقصوصة فقط من الـ JPEG الكامل (حتى لو 50–108 ميغابكسل) فيبقى كل التفصيل الحقيقي */
    private fun prepare(image: ImageProxy, rot: Int, ex: Float, sq: Boolean): Bitmap {
        val m = Matrix().apply { postRotate(rot.toFloat()) }
        if (image.format == ImageFormat.JPEG) {
            val buf = image.planes[0].buffer
            val bytes = ByteArray(buf.remaining()); buf.get(bytes)
            @Suppress("DEPRECATION")
            val dec = BitmapRegionDecoder.newInstance(bytes, 0, bytes.size, false)
            try {
                val r = cropRect(dec.width, dec.height, rot, ex, sq)
                var s = 1
                while (r.width().toLong() * r.height() / (s * s) > 30_000_000L) s *= 2
                val opts = BitmapFactory.Options().apply { inSampleSize = s; inPreferredConfig = Bitmap.Config.ARGB_8888 }
                val part = dec.decodeRegion(r, opts)
                return Bitmap.createBitmap(part, 0, 0, part.width, part.height, m, true)
            } finally { dec.recycle() }
        }
        val src = image.toBitmap()
        val r = cropRect(src.width, src.height, rot, ex, sq)
        return Bitmap.createBitmap(src, r.left, r.top, r.width(), r.height(), m, true)
    }

    /** رفع دقة تدريجي + شحذ تكيّفي (يتجاهل الضجيج) + طابع الأيفون */
    private fun finish(b0: Bitmap, k: Float, ex: Float): Bitmap {
        var b = b0
        val px = b.width.toLong() * b.height
        if (px > 13_000_000L) {
            val f = sqrt(12_500_000.0 / px).toFloat()
            b = Bitmap.createScaledBitmap(b, (b.width * f).toInt(), (b.height * f).toInt(), true)
        }
        val longSide = max(b.width, b.height)
        var up = 1f
        if (longSide < 3600) {
            up = 4000f / longSide
            val tw = (b.width * up).roundToInt(); val th = (b.height * up).roundToInt()
            var cur = b
            while (max(cur.width, cur.height) * 2 <= max(tw, th)) cur = Bitmap.createScaledBitmap(cur, cur.width * 2, cur.height * 2, true)
            if (cur.width != tw) cur = Bitmap.createScaledBitmap(cur, tw, th, true)
            b = cur
        }
        if (!b.isMutable) b = b.copy(Bitmap.Config.ARGB_8888, true)
        val amount = if (up > 1f) (.55f + .3f * ln(up) / ln(2f)).coerceAtMost(1.5f) else if (ex > 1.2f) .5f else .25f
        sharpen(b, amount, if (up > 1f) 7f else 4f)
        if (k > 0f) applyLook(b, k)
        return b
    }

    private fun sharpen(bmp: Bitmap, amount: Float, thr: Float) {
        val w = bmp.width; val h = bmp.height
        val rows = 128
        val buf = IntArray(w * (rows + 2)); val lum = IntArray(w * (rows + 2))
        var y = 0
        while (y < h) {
            val n = min(rows, h - y)
            val y0 = max(0, y - 1); val y1 = min(h, y + n + 1); val rc = y1 - y0
            bmp.getPixels(buf, 0, w, 0, y0, w, rc)
            for (i in 0 until w * rc) {
                val p = buf[i]
                lum[i] = (((p shr 16) and 255) * 77 + ((p shr 8) and 255) * 150 + (p and 255) * 29) shr 8
            }
            val out = IntArray(w * n)
            for (r in 0 until n) {
                val ry = y + r - y0
                val ru = if (y + r > 0) ry - 1 else ry
                val rd = if (y + r < h - 1) ry + 1 else ry
                val bu = ru * w; val bc = ry * w; val bd = rd * w
                for (x in 0 until w) {
                    val xl = if (x > 0) x - 1 else x; val xr = if (x < w - 1) x + 1 else x
                    val blur = (4 * lum[bc + x] + 2 * (lum[bu + x] + lum[bd + x] + lum[bc + xl] + lum[bc + xr]) +
                        lum[bu + xl] + lum[bu + xr] + lum[bd + xl] + lum[bd + xr]) / 16f
                    val d = lum[bc + x] - blur
                    val ad = abs(d)
                    var e = if (ad < thr) d * (ad / thr) else d      // تخفيف الضجيج في المناطق المسطّحة
                    e = (e * amount).coerceIn(-45f, 45f)
                    val ei = e.roundToInt()
                    val p = buf[bc + x]
                    val nr = (((p shr 16) and 255) + ei).coerceIn(0, 255)
                    val ng = (((p shr 8) and 255) + ei).coerceIn(0, 255)
                    val nb = ((p and 255) + ei).coerceIn(0, 255)
                    out[r * w + x] = (p and 0xFF000000.toInt()) or (nr shl 16) or (ng shl 8) or nb
                }
            }
            bmp.setPixels(out, 0, w, 0, y, w, n)
            y += n
        }
    }

    private fun applyLook(bmp: Bitmap, k: Float) {
        val w = bmp.width; val h = bmp.height
        val lut = IntArray(256) { (curve(it / 255f, k) * 255f + .5f).toInt() }
        val wr = 1f + .025f * k; val wb = 1f - .035f * k; val sat = 1f - .06f * k
        val rows = 256; val buf = IntArray(w * rows)
        fun cl(f: Float) = if (f < 0f) 0 else if (f > 255f) 255 else f.toInt()
        var y = 0
        while (y < h) {
            val n = min(rows, h - y)
            bmp.getPixels(buf, 0, w, 0, y, w, n)
            for (i in 0 until w * n) {
                val px = buf[i]
                var r = ((px shr 16) and 255) * wr; var g = ((px shr 8) and 255).toFloat(); var b = (px and 255) * wb
                val l = .299f * r + .587f * g + .114f * b
                r = l + (r - l) * sat; g = l + (g - l) * sat; b = l + (b - l) * sat
                buf[i] = (px and 0xFF000000.toInt()) or (lut[cl(r)] shl 16) or (lut[cl(g)] shl 8) or lut[cl(b)]
            }
            bmp.setPixels(buf, 0, w, 0, y, w, n)
            y += n
        }
    }

    private fun save(bmp: Bitmap): Uri? {
        val name = "IMG_${System.currentTimeMillis()}.jpg"
        val cv = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/iCam")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv) ?: return null
        contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
        cv.clear(); cv.put(MediaStore.Images.Media.IS_PENDING, 0)
        contentResolver.update(uri, cv, null, null)
        return uri
    }

    private fun onSaved(uri: Uri?, tb: Bitmap, vb: Bitmap) {
        lastUri = uri; lastView = vb
        thumb.setImageBitmap(tb)
        thumb.scaleX = .4f; thumb.scaleY = .4f
        thumb.animate().scaleX(1f).scaleY(1f).setDuration(420).setInterpolator(OvershootInterpolator(2.4f)).start()
    }

    // ───────────────────────── viewer
    private fun openViewer() {
        val b = lastView ?: return
        viewerImg.setImageBitmap(b)
        val loc = IntArray(2); thumb.getLocationOnScreen(loc)
        viewerImg.pivotX = loc[0] + thumb.width / 2f; viewerImg.pivotY = loc[1] + thumb.height / 2f
        viewer.visibility = View.VISIBLE; viewer.alpha = 0f; viewerImg.scaleX = .2f; viewerImg.scaleY = .2f
        viewer.animate().alpha(1f).setDuration(240).start()
        viewerImg.animate().scaleX(1f).scaleY(1f).setDuration(340).setInterpolator(DecelerateInterpolator(1.7f)).start()
    }
    private fun closeViewer() {
        viewerImg.animate().scaleX(.2f).scaleY(.2f).setDuration(260).setInterpolator(DecelerateInterpolator()).start()
        viewer.animate().alpha(0f).setDuration(260).withEndAction { viewer.visibility = View.GONE }.start()
    }
    private fun shareLast() {
        val u = lastUri ?: return
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "image/jpeg"; putExtra(Intent.EXTRA_STREAM, u); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }, "Share"))
    }
}
