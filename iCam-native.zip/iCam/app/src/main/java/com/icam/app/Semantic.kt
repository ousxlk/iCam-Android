package com.icam.app

import android.graphics.*
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.Segmenter
import kotlin.math.*

/** قناع شخص (0..1) من نموذج التجزئة الدلالية */
class PMask(val w: Int, val h: Int, val v: FloatArray) {
    fun at(nx: Float, ny: Float): Float {
        val x = (nx * (w - 1)).coerceIn(0f, (w - 1).toFloat()); val y = (ny * (h - 1)).coerceIn(0f, (h - 1).toFloat())
        val x0 = x.toInt(); val y0 = y.toInt(); val x1 = min(x0 + 1, w - 1); val y1 = min(y0 + 1, h - 1)
        val fx = x - x0; val fy = y - y0
        val a = v[y0 * w + x0] * (1 - fx) + v[y0 * w + x1] * fx
        val b = v[y1 * w + x0] * (1 - fx) + v[y1 * w + x1] * fx
        return a * (1 - fy) + b * fy
    }
    fun coverage(): Float { var c = 0; for (f in v) if (f > .5f) c++; return c.toFloat() / v.size }
}

object Semantic {
    private fun lum(p: Int) = (((p shr 16) and 255) * 77 + ((p shr 8) and 255) * 150 + (p and 255) * 29) shr 8

    /** يجب استدعاؤها من خيط خلفي */
    fun personMask(bmp: Bitmap, seg: Segmenter): PMask? {
        return try {
            val r = 512f / max(bmp.width, bmp.height)
            val sm = if (r < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * r).toInt(), (bmp.height * r).toInt(), true) else bmp
            val mask = Tasks.await(seg.process(InputImage.fromBitmap(sm, 0)))
            val buf = mask.buffer
            buf.rewind()
            val n = mask.width * mask.height
            val arr = FloatArray(n)
            for (i in 0 until n) arr[i] = buf.getFloat()
            PMask(mask.width, mask.height, arr)
        } catch (e: Exception) { null }
    }

    /** مرشّح ثنائي (Bilateral) 3×3: يُنعّم الضجيج في المناطق المسطّحة ويحفظ الحواف */
    fun denoise(bmp: Bitmap, strength: Float) {
        val w = bmp.width; val h = bmp.height
        val hh = 5f + 16f * strength
        val rows = 128
        val buf = IntArray(w * (rows + 2)); val lm = IntArray(w * (rows + 2))
        var y = 0
        while (y < h) {
            val n = min(rows, h - y)
            val y0 = max(0, y - 1); val y1 = min(h, y + n + 1); val rc = y1 - y0
            bmp.getPixels(buf, 0, w, 0, y0, w, rc)
            for (i in 0 until w * rc) lm[i] = lum(buf[i])
            val out = IntArray(w * n)
            for (r in 0 until n) {
                val ry = y + r - y0
                val ru = if (y + r > 0) ry - 1 else ry
                val rd = if (y + r < h - 1) ry + 1 else ry
                for (x in 0 until w) {
                    val xl = if (x > 0) x - 1 else x; val xr = if (x < w - 1) x + 1 else x
                    val c = buf[ry * w + x]; val lc = lm[ry * w + x]
                    var sr = ((c shr 16) and 255).toFloat(); var sg = ((c shr 8) and 255).toFloat(); var sb = (c and 255).toFloat()
                    var sw = 1f
                    for (k in 0 until 8) {
                        val rr = when (k) { 0, 1, 2 -> ru; 3, 4 -> ry; else -> rd }
                        val cc = when (k) { 0, 3, 5 -> xl; 1, 6 -> x; else -> xr }
                        val idx = rr * w + cc
                        val d = abs(lm[idx] - lc) / hh
                        val wt = 1f / (1f + d * d * d * d)
                        val p = buf[idx]
                        sr += wt * ((p shr 16) and 255); sg += wt * ((p shr 8) and 255); sb += wt * (p and 255); sw += wt
                    }
                    out[r * w + x] = (c and 0xFF000000.toInt()) or ((sr / sw).roundToInt() shl 16) or ((sg / sw).roundToInt() shl 8) or (sb / sw).roundToInt()
                }
            }
            bmp.setPixels(out, 0, w, 0, y, w, n)
            y += n
        }
    }

    /**
     * Tone mapping موضعي (على غرار Smart HDR): تُحسب طبقة الإضاءة الخفيفة (ضبابية)،
     * تُرفع ظلالها وتُضغط إضاءاتها، ثم يُضرب كل بكسل بالنسبة نفسها فتبقى التفاصيل.
     * وبنفس المرور: حماية لون البشرة (من القناع) وتعميق السماء (استدلالياً).
     */
    fun localTone(b: Bitmap, strength: Float, autoGain: Boolean, mask: PMask?) {
        val w = b.width; val h = b.height
        val cs = 8
        val cw = (w + cs - 1) / cs; val ch = (h + cs - 1) / cs
        val sum = FloatArray(cw * ch); val cnt = IntArray(cw * ch)
        val rows = 128; val buf = IntArray(w * rows)
        var y = 0
        while (y < h) {
            val n = min(rows, h - y)
            b.getPixels(buf, 0, w, 0, y, w, n)
            for (r in 0 until n) {
                val cy = (y + r) / cs
                var x = 0
                while (x < w) { val i = cy * cw + x / cs; sum[i] += lum(buf[r * w + x]).toFloat(); cnt[i]++; x += 2 }
            }
            y += n
        }
        val base = FloatArray(cw * ch) { if (cnt[it] > 0) sum[it] / cnt[it] else 128f }
        val bl = FloatArray(cw * ch)
        for (cy in 0 until ch) for (cx in 0 until cw) {
            var s = 0f; var c = 0
            for (oy in -1..1) for (ox in -1..1) { s += base[(cy + oy).coerceIn(0, ch - 1) * cw + (cx + ox).coerceIn(0, cw - 1)]; c++ }
            bl[cy * cw + cx] = s / c
        }
        var gain = 1f
        if (autoGain) {
            val hist = IntArray(256); for (v in bl) hist[v.toInt().coerceIn(0, 255)]++
            var acc = 0; val tot = bl.size; var p98 = 255
            for (i in 0..255) { acc += hist[i]; if (acc >= tot * 0.98f) { p98 = i; break } }
            gain = (190f / max(p98.toFloat(), 40f)).coerceIn(1f, 2.4f)
        }
        // جدول نسبة التعديل لكل مستوى إضاءة محلي
        val ratio = FloatArray(256) {
            val v = max(it, 6) / 255f
            var t = v.pow(1f / (1f + .55f * strength)) * gain
            if (t > .8f) t = .8f + (t - .8f) * (1f - .45f * strength)
            (t / v).coerceIn(.75f, 2.8f)
        }
        val xi = IntArray(w); val xf = FloatArray(w)
        for (x in 0 until w) {
            val fx = (x / cs.toFloat() - .5f).coerceIn(0f, (cw - 1).toFloat())
            xi[x] = min(fx.toInt(), cw - 1); xf[x] = fx - fx.toInt()
        }
        y = 0
        while (y < h) {
            val n = min(rows, h - y)
            b.getPixels(buf, 0, w, 0, y, w, n)
            for (r in 0 until n) {
                val yy = y + r
                val fy = (yy / cs.toFloat() - .5f).coerceIn(0f, (ch - 1).toFloat())
                val y0 = min(fy.toInt(), ch - 1); val y1 = min(y0 + 1, ch - 1); val ty = fy - y0
                val ny = yy / h.toFloat()
                for (x in 0 until w) {
                    val x0 = xi[x]; val x1 = min(x0 + 1, cw - 1); val tx = xf[x]
                    val lb = (bl[y0 * cw + x0] * (1 - tx) + bl[y0 * cw + x1] * tx) * (1 - ty) +
                        (bl[y1 * cw + x0] * (1 - tx) + bl[y1 * cw + x1] * tx) * ty
                    var g = ratio[lb.toInt().coerceIn(0, 255)]
                    val m = if (mask != null) mask.at(x / w.toFloat(), ny) else 0f
                    if (m > 0f) g = 1f + (g - 1f) * (1f - .4f * m)          // حماية الأشخاص من الإفراط
                    val p = buf[r * w + x]
                    var rr = ((p shr 16) and 255) * g; var gg = ((p shr 8) and 255) * g; var bb = (p and 255) * g
                    val mx = max(rr, max(gg, bb)); val mn = min(rr, min(gg, bb))
                    val sat = (mx - mn) / (mx + 1f)
                    val l = .299f * rr + .587f * gg + .114f * bb
                    if (m > .5f && rr > gg && gg > bb && sat > .45f) {        // بشرة: كبح التشبّع الزائد
                        val k = (sat - .45f) * .5f
                        rr += (l - rr) * k; gg += (l - gg) * k; bb += (l - bb) * k
                    } else if (m < .3f && ny < .62f && bb > rr + 14f && bb >= gg && l > 100f) {   // سماء (استدلالي)
                        rr *= .97f; gg *= .99f; bb *= 1.03f
                    }
                    buf[r * w + x] = (p and 0xFF000000.toInt()) or (min(255, rr.toInt()) shl 16) or (min(255, gg.toInt()) shl 8) or min(255, bb.toInt())
                }
            }
            b.setPixels(buf, 0, w, 0, y, w, n)
            y += n
        }
    }

    /** يخفّف أثر الفلتر الملوّن على الأشخاص (يحمي لون البشرة) */
    fun protectPeople(filtered: Bitmap, original: Bitmap, mask: PMask, amount: Float) {
        val w = filtered.width; val h = filtered.height
        val rows = 128; val a = IntArray(w * rows); val o = IntArray(w * rows)
        var y = 0
        while (y < h) {
            val n = min(rows, h - y)
            filtered.getPixels(a, 0, w, 0, y, w, n); original.getPixels(o, 0, w, 0, y, w, n)
            for (r in 0 until n) {
                val ny = (y + r) / h.toFloat()
                for (x in 0 until w) {
                    val m = mask.at(x / w.toFloat(), ny) * amount
                    if (m <= .02f) continue
                    val i = r * w + x; val p = a[i]; val q = o[i]
                    val rr = (((p shr 16) and 255) * (1 - m) + ((q shr 16) and 255) * m).toInt()
                    val gg = (((p shr 8) and 255) * (1 - m) + ((q shr 8) and 255) * m).toInt()
                    val bb = ((p and 255) * (1 - m) + (q and 255) * m).toInt()
                    a[i] = (p and 0xFF000000.toInt()) or (rr shl 16) or (gg shl 8) or bb
                }
            }
            filtered.setPixels(a, 0, w, 0, y, w, n)
            y += n
        }
    }

    private fun boxBlur(a: IntArray, w: Int, h: Int, r: Int) {
        val tmp = IntArray(max(w, h))
        val win = 2 * r + 1
        for (y in 0 until h) {
            val base = y * w; var sum = 0
            for (i in -r..r) sum += a[base + i.coerceIn(0, w - 1)]
            for (x in 0 until w) {
                tmp[x] = sum / win
                sum += a[base + min(x + r + 1, w - 1)] - a[base + max(x - r, 0)]
            }
            for (x in 0 until w) a[base + x] = tmp[x]
        }
        for (x in 0 until w) {
            var sum = 0
            for (i in -r..r) sum += a[i.coerceIn(0, h - 1) * w + x]
            for (y in 0 until h) {
                tmp[y] = sum / win
                sum += a[min(y + r + 1, h - 1) * w + x] - a[max(y - r, 0) * w + x]
            }
            for (y in 0 until h) a[y * w + x] = tmp[y]
        }
    }

    /** وضع Portrait: تمويه الخلفية بقناع الشخص مع حواف ناعمة (لا يوجد عمق حقيقي، فالتمويه ثابت) */
    fun portrait(b: Bitmap, mask: PMask, strength: Float) {
        val w = b.width; val h = b.height
        val f = 4; val sw = max(8, w / f); val sh = max(8, h / f)
        val small = Bitmap.createScaledBitmap(b, sw, sh, true)
        val px = IntArray(sw * sh); small.getPixels(px, 0, sw, 0, 0, sw, sh)
        val R = IntArray(sw * sh) { (px[it] shr 16) and 255 }
        val G = IntArray(sw * sh) { (px[it] shr 8) and 255 }
        val B = IntArray(sw * sh) { px[it] and 255 }
        val rad = max(2, (sw * .014f * strength).roundToInt())
        repeat(2) { boxBlur(R, sw, sh, rad); boxBlur(G, sw, sh, rad); boxBlur(B, sw, sh, rad) }
        for (i in px.indices) px[i] = (0xFF shl 24) or (R[i] shl 16) or (G[i] shl 8) or B[i]
        val blurSmall = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888)
        blurSmall.setPixels(px, 0, sw, 0, 0, sw, sh)
        val bg = Bitmap.createScaledBitmap(blurSmall, w, h, true)
        val rows = 128; val a = IntArray(w * rows); val o = IntArray(w * rows)
        var y = 0
        while (y < h) {
            val n = min(rows, h - y)
            b.getPixels(a, 0, w, 0, y, w, n); bg.getPixels(o, 0, w, 0, y, w, n)
            for (r in 0 until n) {
                val ny = (y + r) / h.toFloat()
                for (x in 0 until w) {
                    var m = mask.at(x / w.toFloat(), ny)
                    m = ((m - .25f) / .5f).coerceIn(0f, 1f); m = m * m * (3f - 2f * m)
                    if (m >= .999f) continue
                    val i = r * w + x; val p = a[i]; val q = o[i]
                    val rr = (((p shr 16) and 255) * m + ((q shr 16) and 255) * (1 - m)).toInt()
                    val gg = (((p shr 8) and 255) * m + ((q shr 8) and 255) * (1 - m)).toInt()
                    val bb = ((p and 255) * m + (q and 255) * (1 - m)).toInt()
                    a[i] = (p and 0xFF000000.toInt()) or (rr shl 16) or (gg shl 8) or bb
                }
            }
            b.setPixels(a, 0, w, 0, y, w, n)
            y += n
        }
    }
}
