package com.icam.app

import android.graphics.*
import kotlin.math.*

/** إطار JPEG مخزّن مع زاوية تدويره */
class Frame(val jpeg: ByteArray, val rot: Int)

/**
 * دمج عدة إطارات (Multi-frame Fusion):
 *  1) اختيار الإطار المرجعي الأوضح (Lock-in frame)
 *  2) محاذاة هرمية بالقطع (Tile alignment): خشنة عند 1/4 ثم دقيقة بدقة كاملة
 *  3) دمج مرجّح لكل بكسل: يُرفض ما يختلف عن المرجع (حركة/أشباح) حسب نموذج ضجيج
 *  4) وضع HDR: أوزان "حسن التعريض" (Exposure Fusion) بدل وزن الاتساق
 */
object Fusion {
    private const val T = 64          // حجم القطعة
    private const val MARGIN = 30     // هامش الإزاحة القصوى

    private fun lum(p: Int) = (((p shr 16) and 255) * 77 + ((p shr 8) and 255) * 150 + (p and 255) * 29) shr 8

    fun cropRect(sw: Int, sh: Int, rot: Int, ex: Float, sq: Boolean): Rect {
        val rotated = rot % 180 != 0
        val uw = (if (rotated) sh else sw).toFloat(); val uh = (if (rotated) sw else sh).toFloat()
        var cw = uw / ex; var ch = uh / ex
        if (sq) { val s = min(cw, ch); cw = s; ch = s }
        val cwS = (if (rotated) ch else cw).roundToInt().coerceIn(2, sw)
        val chS = (if (rotated) cw else ch).roundToInt().coerceIn(2, sh)
        val sx = (sw - cwS) / 2; val sy = (sh - chS) / 2
        return Rect(sx, sy, sx + cwS, sy + chS)
    }

    /** فكّ ترميز المنطقة المقصوصة فقط (زوم رقمي) وتدويرها لتصبح معتدلة */
    fun decodeCrop(f: Frame, ex: Float, sq: Boolean): Bitmap {
        val m = Matrix().apply { postRotate(f.rot.toFloat()) }
        @Suppress("DEPRECATION")
        val dec = BitmapRegionDecoder.newInstance(f.jpeg, 0, f.jpeg.size, false)
        try {
            val r = cropRect(dec.width, dec.height, f.rot, ex, sq)
            var s = 1
            while (r.width().toLong() * r.height() / (s * s) > 30_000_000L) s *= 2
            val o = BitmapFactory.Options().apply { inSampleSize = s; inPreferredConfig = Bitmap.Config.ARGB_8888 }
            val part = dec.decodeRegion(r, o)
            return Bitmap.createBitmap(part, 0, 0, part.width, part.height, m, true)
        } finally { dec.recycle() }
    }

    /** مقياس الحدّة (تباين لابلاس) لاختيار أوضح إطار */
    fun sharpness(f: Frame): Float {
        val o = BitmapFactory.Options().apply { inSampleSize = 4 }
        val b = BitmapFactory.decodeByteArray(f.jpeg, 0, f.jpeg.size, o) ?: return 0f
        val w = b.width; val h = b.height
        val px = IntArray(w * h); b.getPixels(px, 0, w, 0, 0, w, h)
        var s = 0L; var n = 0
        for (y in 1 until h - 1 step 2) for (x in 1 until w - 1 step 2) {
            val i = y * w + x
            s += abs(4 * lum(px[i]) - lum(px[i - 1]) - lum(px[i + 1]) - lum(px[i - w]) - lum(px[i + w])); n++
        }
        b.recycle()
        return if (n > 0) s.toFloat() / n else 0f
    }

    private fun lumaOf(b: Bitmap): ByteArray {
        val w = b.width; val h = b.height
        val out = ByteArray(w * h)
        val buf = IntArray(w * 128)
        var y = 0
        while (y < h) {
            val n = min(128, h - y)
            b.getPixels(buf, 0, w, 0, y, w, n)
            for (i in 0 until w * n) out[y * w + i] = lum(buf[i]).toByte()
            y += n
        }
        return out
    }

    private fun meanOf(l: ByteArray): Float {
        var s = 0L; var c = 0; var i = 0
        while (i < l.size) { s += l[i].toInt() and 255; c++; i += 7 }
        return if (c > 0) s.toFloat() / c else 128f
    }

    private class Offsets(val tx: Int, val ty: Int, val dx: IntArray, val dy: IntArray)

    private fun down4(src: ByteArray, w: Int, h: Int, w4: Int, h4: Int, gainQ: Int): ByteArray {
        val out = ByteArray(w4 * h4)
        for (y in 0 until h4) for (x in 0 until w4) {
            var s = 0
            for (dy in 0..3) { val row = (y * 4 + dy) * w + x * 4; for (dx in 0..3) s += src[row + dx].toInt() and 255 }
            var v = ((s shr 4) * gainQ) shr 8
            if (v > 255) v = 255
            out[y * w4 + x] = v.toByte()
        }
        return out
    }

    /** إزاحة كل قطعة 64×64: (dx,dy) بحيث يقابل البكسل (x+dx, y+dy) في الإطار الحالي البكسل (x,y) في المرجع */
    private fun align(ref: ByteArray, cur: ByteArray, w: Int, h: Int, gainQ: Int): Offsets {
        val tx = (w + T - 1) / T; val ty = (h + T - 1) / T
        val w4 = w / 4; val h4 = h / 4
        val r4 = down4(ref, w, h, w4, h4, 256); val c4 = down4(cur, w, h, w4, h4, gainQ)
        val nT = tx * ty
        val cdx = IntArray(nT); val cdy = IntArray(nT); val ok = BooleanArray(nT)
        val tt = T / 4; val S = 6
        for (j in 0 until ty) for (i in 0 until tx) {
            val ox0 = i * tt; val oy0 = j * tt
            if (ox0 + tt > w4 || oy0 + tt > h4) continue
            var s = 0; var s2 = 0; var c = 0
            var yy = oy0
            while (yy < oy0 + tt) {
                var xx = ox0
                while (xx < ox0 + tt) { val v = r4[yy * w4 + xx].toInt() and 255; s += v; s2 += v * v; c++; xx += 2 }
                yy += 2
            }
            val mean = s / c
            if (s2 / c - mean * mean < 30) continue      // قطعة بلا نسيج: نستخدم الإزاحة العامة
            var best = Int.MAX_VALUE; var bx = 0; var by = 0
            for (oy in -S..S) for (ox in -S..S) {
                var sad = 0
                var y2 = oy0
                while (y2 < oy0 + tt) {
                    val cy = (y2 + oy).coerceIn(0, h4 - 1)
                    var x2 = ox0
                    while (x2 < ox0 + tt) {
                        val cx = (x2 + ox).coerceIn(0, w4 - 1)
                        sad += abs((r4[y2 * w4 + x2].toInt() and 255) - (c4[cy * w4 + cx].toInt() and 255))
                        x2 += 2
                    }
                    y2 += 2
                }
                sad += (abs(ox) + abs(oy)) * 3
                if (sad < best) { best = sad; bx = ox; by = oy }
            }
            val id = j * tx + i
            cdx[id] = bx; cdy[id] = by; ok[id] = true
        }
        val xs = ArrayList<Int>(); val ys = ArrayList<Int>()
        for (k in 0 until nT) if (ok[k]) { xs.add(cdx[k]); ys.add(cdy[k]) }
        xs.sort(); ys.sort()
        val gx = if (xs.isEmpty()) 0 else xs[xs.size / 2]
        val gy = if (ys.isEmpty()) 0 else ys[ys.size / 2]
        for (k in 0 until nT) if (!ok[k]) { cdx[k] = gx; cdy[k] = gy }

        val dx = IntArray(nT); val dy = IntArray(nT)
        for (j in 0 until ty) for (i in 0 until tx) {
            val id = j * tx + i
            val cx0 = cdx[id] * 4; val cy0 = cdy[id] * 4
            val x0 = i * T; val y0 = j * T; val x1 = min(w, x0 + T); val y1 = min(h, y0 + T)
            var best = Int.MAX_VALUE; var bdx = cx0; var bdy = cy0
            for (oy in -3..3) for (ox in -3..3) {
                var sad = 0
                var y = y0
                while (y < y1) {
                    val sy = (y + cy0 + oy).coerceIn(0, h - 1)
                    var x = x0
                    while (x < x1) {
                        val sx = (x + cx0 + ox).coerceIn(0, w - 1)
                        var cv = ((cur[sy * w + sx].toInt() and 255) * gainQ) shr 8
                        if (cv > 255) cv = 255
                        sad += abs((ref[y * w + x].toInt() and 255) - cv)
                        x += 4
                    }
                    y += 4
                }
                sad += abs(ox) + abs(oy)
                if (sad < best) { best = sad; bdx = cx0 + ox; bdy = cy0 + oy }
            }
            dx[id] = bdx; dy[id] = bdy
        }
        return Offsets(tx, ty, dx, dy)
    }

    private fun accumulateRef(b: Bitmap, hdr: Boolean, lut: IntArray, aR: ShortArray, aG: ShortArray, aB: ShortArray, aW: ShortArray) {
        val w = b.width; val h = b.height
        val buf = IntArray(w * 128)
        var y = 0
        while (y < h) {
            val n = min(128, h - y)
            b.getPixels(buf, 0, w, 0, y, w, n)
            for (i in 0 until w * n) {
                val p = buf[i]
                val wt = if (hdr) lut[lum(p)] else 16
                val idx = y * w + i
                aR[idx] = (wt * ((p shr 16) and 255)).toShort()
                aG[idx] = (wt * ((p shr 8) and 255)).toShort()
                aB[idx] = (wt * (p and 255)).toShort()
                aW[idx] = wt.toShort()
            }
            y += n
        }
    }

    private fun accumulate(b: Bitmap, off: Offsets, refL: ByteArray, hdr: Boolean, lut: IntArray, noise: Float,
                           aR: ShortArray, aG: ShortArray, aB: ShortArray, aW: ShortArray, w: Int, h: Int) {
        val buf = IntArray(w * (T + 2 * MARGIN))
        for (ty in 0 until off.ty) {
            val y0 = ty * T; val y1 = min(h, y0 + T)
            val rs = max(0, y0 - MARGIN); val re = min(h, y1 + MARGIN)
            b.getPixels(buf, 0, w, 0, rs, w, re - rs)
            for (y in y0 until y1) {
                val rowBase = y * w
                for (x in 0 until w) {
                    val t = ty * off.tx + x / T
                    val sx = (x + off.dx[t]).coerceIn(0, w - 1)
                    val sy = (y + off.dy[t]).coerceIn(rs, re - 1)
                    val p = buf[(sy - rs) * w + sx]
                    val r = (p shr 16) and 255; val g = (p shr 8) and 255; val bl = p and 255
                    val lj = (r * 77 + g * 150 + bl * 29) shr 8
                    val idx = rowBase + x
                    val wt: Int
                    if (hdr) {
                        wt = lut[lj]
                    } else {
                        val lr = refL[idx].toInt() and 255
                        val d = abs(lj - lr).toFloat()
                        val sg = noise * (3f + .04f * lr)
                        val q = d / (2.2f * sg)
                        val u = 1f + q * q
                        wt = (16f / (u * u)).toInt()
                    }
                    if (wt <= 0) continue
                    aR[idx] = ((aR[idx].toInt() and 0xFFFF) + wt * r).toShort()
                    aG[idx] = ((aG[idx].toInt() and 0xFFFF) + wt * g).toShort()
                    aB[idx] = ((aB[idx].toInt() and 0xFFFF) + wt * bl).toShort()
                    aW[idx] = ((aW[idx].toInt() and 0xFFFF) + wt).toShort()
                }
            }
        }
    }

    private fun compose(aR: ShortArray, aG: ShortArray, aB: ShortArray, aW: ShortArray, w: Int, h: Int): Bitmap {
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val buf = IntArray(w * 128)
        var y = 0
        while (y < h) {
            val n = min(128, h - y)
            for (i in 0 until w * n) {
                val idx = y * w + i
                val ww = max(1, aW[idx].toInt() and 0xFFFF)
                val r = ((aR[idx].toInt() and 0xFFFF) + ww / 2) / ww
                val g = ((aG[idx].toInt() and 0xFFFF) + ww / 2) / ww
                val b = ((aB[idx].toInt() and 0xFFFF) + ww / 2) / ww
                buf[i] = (0xFF shl 24) or (min(r, 255) shl 16) or (min(g, 255) shl 8) or min(b, 255)
            }
            out.setPixels(buf, 0, w, 0, y, w, n)
            y += n
        }
        return out
    }

    /**
     * @param hdr  إطارات بتعريضات مختلفة (الإطار 0 هو المرجع)، وإلا إطارات متتالية للتقليل من الضجيج
     * @param noise معامل نموذج الضجيج (أكبر = تساهل أكثر في الدمج، يُستخدم في الليل)
     */
    fun merge(frames: List<Frame>, hdr: Boolean, ex: Float, sq: Boolean, noise: Float, onProgress: (Int) -> Unit): Bitmap? {
        if (frames.isEmpty()) return null
        val refIdx = if (hdr) 0 else (frames.indices.maxByOrNull { sharpness(frames[it]) } ?: 0)
        val refRaw = decodeCrop(frames[refIdx], ex, sq)
        val long = max(refRaw.width, refRaw.height)
        val up = if (long < 2600 && long * 2 <= 4800) 2 else 1      // دقة أعلى قبل الدمج = معلومات شبه-بكسلية من اهتزاز اليد
        val ref = if (up > 1) Bitmap.createScaledBitmap(refRaw, refRaw.width * up, refRaw.height * up, true) else refRaw
        val w = ref.width; val h = ref.height
        val n = w * h
        val aR = ShortArray(n); val aG = ShortArray(n); val aB = ShortArray(n); val aW = ShortArray(n)
        val refL = lumaOf(ref)
        val meanRef = meanOf(refL)
        val lut = IntArray(256) { max(1, (16f * exp(-((it - 128f) * (it - 128f)) / (2f * 72f * 72f))).roundToInt()) }
        accumulateRef(ref, hdr, lut, aR, aG, aB, aW)
        var done = 1
        for (j in frames.indices) {
            if (j == refIdx) continue
            val raw = decodeCrop(frames[j], ex, sq)
            val b = if (up > 1) Bitmap.createScaledBitmap(raw, raw.width * up, raw.height * up, true) else raw
            if (b.width != w || b.height != h) continue
            val l = lumaOf(b)
            val gain = if (hdr) (meanRef * 256f / max(1f, meanOf(l))).toInt().coerceIn(64, 1024) else 256
            val off = align(refL, l, w, h, gain)
            accumulate(b, off, refL, hdr, lut, noise, aR, aG, aB, aW, w, h)
            b.recycle()
            done++; onProgress(done)
        }
        return compose(aR, aG, aB, aW, w, h)
    }
}
